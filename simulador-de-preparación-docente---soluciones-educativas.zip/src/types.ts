export interface QuestionOption {
  letter: 'A' | 'B' | 'C' | 'D';
  text: string;
}

export interface Question {
  id: number;
  dimension: 2 | 3; // 2: Responsabilidad Profesional, 3: Competencias Socioemocionales
  category: string;
  questionText: string;
  options: QuestionOption[];
  correctLetter: 'A' | 'B' | 'C' | 'D';
  justification?: string; // The note in parentheses, like "(Principio medular del DUA y la inclusión)"
}

export interface ExamAttempt {
  id: string;
  date: string;
  dimension: 2 | 3 | 'both';
  score: number; // Percentage
  correctCount: number;
  totalCount: number;
  timeSpentSeconds: number;
  completed: boolean;
  answers: { [questionId: number]: 'A' | 'B' | 'C' | 'D' };
}

export interface QuestionStats {
  questionId: number;
  timesAnswered: number;
  correctAnswers: number;
  isFavorite: boolean;
  userNote?: string;
}

export interface CategoryStats {
  name: string;
  dimension: 2 | 3;
  total: number;
  correct: number;
}
