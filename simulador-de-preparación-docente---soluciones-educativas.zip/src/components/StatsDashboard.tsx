import React, { useMemo, useState } from 'react';
import { Question, ExamAttempt, QuestionStats } from '../types';
import { Award, BookmarkCheck, BookOpen, Clock, Calendar, CheckCircle2, ChevronRight, PenTool, Trash2, TrendingUp, HelpCircle, AlertTriangle } from 'lucide-react';

interface StatsDashboardProps {
  questions: Question[];
  stats: { [id: number]: QuestionStats };
  attempts: ExamAttempt[];
  onClearAttempts: () => void;
  onNavigateToQuestion: (id: number) => void;
}

export default function StatsDashboard({ questions, stats, attempts, onClearAttempts, onNavigateToQuestion }: StatsDashboardProps) {
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Aggregate data
  const totalAttempts = attempts.length;
  
  const averageScore = useMemo(() => {
    if (totalAttempts === 0) return 0;
    const total = attempts.reduce((acc, curr) => acc + curr.score, 0);
    return Math.round(total / totalAttempts);
  }, [attempts, totalAttempts]);

  const bookmarkedQuestions = useMemo(() => {
    return questions.filter(q => stats[q.id]?.isFavorite);
  }, [questions, stats]);

  const questionsWithNotes = useMemo(() => {
    return questions.filter(q => stats[q.id]?.userNote && stats[q.id]?.userNote!.trim() !== '');
  }, [questions, stats]);

  // Performance progress tier
  const performanceTier = useMemo(() => {
    if (totalAttempts === 0) return { label: "No Iniciado", desc: "Completa tu primer simulador de examen para medir tu nivel.", color: "text-slate-500 bg-slate-100" };
    if (averageScore >= 90) return { label: "Excelente", desc: "¡Sobresaliente! Tienes una preparación óptima para la evaluación.", color: "text-emerald-700 bg-emerald-50 border border-emerald-200" };
    if (averageScore >= 70) return { label: "Muy Bueno", desc: "Vas por buen camino. Sigue repasando tus debilidades en el simulador.", color: "text-indigo-700 bg-indigo-50 border border-indigo-200" };
    return { label: "Requiere Refuerzo", desc: "Dedica más tiempo a la Guía de Estudio y al repaso de los distractores fallados.", color: "text-amber-700 bg-amber-50 border border-amber-200" };
  }, [averageScore, totalAttempts]);

  return (
    <div className="space-y-6" id="stats-dashboard-container">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-800 shrink-0">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-slate-400 text-xs font-sans">Simulaciones Hechas</span>
            <strong className="text-slate-800 text-xl md:text-2xl font-mono">{totalAttempts}</strong>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 shrink-0">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-slate-400 text-xs font-sans">Puntuación Promedio</span>
            <strong className="text-indigo-600 text-xl md:text-2xl font-mono">{averageScore}%</strong>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-50 rounded-xl flex items-center justify-center text-amber-500 shrink-0">
            <BookmarkCheck className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-slate-400 text-xs font-sans">Favoritos Guardados</span>
            <strong className="text-amber-600 text-xl md:text-2xl font-mono">{bookmarkedQuestions.length}</strong>
          </div>
          <div className="text-slate-500 shrink-0" />
        </div>

        {/* Metric 4 */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 shrink-0">
            <PenTool className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-slate-400 text-xs font-sans">Notas de Estudio</span>
            <strong className="text-indigo-600 text-xl md:text-2xl font-mono">{questionsWithNotes.length}</strong>
          </div>
        </div>
      </div>

      {/* Main Stats Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Side: Performance and History */}
        <div className="lg:col-span-2 space-y-6">
          {/* Level overview */}
          <div className={`p-6 rounded-2xl ${performanceTier.color} space-y-2`}>
            <div className="flex justify-between items-center">
              <h4 className="font-serif font-bold text-base md:text-lg">Nivel de Preparación Actual</h4>
              <span className="text-xs uppercase font-bold tracking-widest px-2.5 py-0.5 rounded-full bg-white/50 border">
                {performanceTier.label}
              </span>
            </div>
            <p className="text-sm leading-relaxed opacity-90">{performanceTier.desc}</p>
          </div>

          {/* Past Attempts Table */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
            <div className="px-5 py-4 bg-slate-50/50 border-b border-slate-100 flex justify-between items-center">
              <h4 className="font-serif font-bold text-slate-800 text-sm md:text-base">Historial de Intentos</h4>
              {totalAttempts > 0 && (
                <>
                  <button
                    onClick={() => setShowClearConfirm(true)}
                    className="text-xs text-rose-500 hover:text-rose-600 flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Borrar Historial</span>
                  </button>

                  {/* Custom Clear History Confirmation Modal */}
                  {showClearConfirm && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in" id="clear-confirm-modal">
                      {/* Backdrop */}
                      <div 
                        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
                        onClick={() => setShowClearConfirm(false)}
                      />
                      {/* Content Card */}
                      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 relative z-10 space-y-4 text-slate-900 text-left">
                        <div className="w-12 h-12 bg-rose-50 rounded-full flex items-center justify-center text-rose-500 mx-auto">
                          <Trash2 className="w-6 h-6" />
                        </div>
                        <div className="text-center space-y-1.5">
                          <h4 className="font-serif font-bold text-lg text-slate-800">¿Borrar Historial de Intentos?</h4>
                          <p className="text-xs text-slate-500 leading-relaxed">
                            Esta acción <strong className="text-rose-600 font-bold">eliminará de forma permanente</strong> todos los registros de simulaciones pasadas en tu historial. Tus favoritos y notas personales no se verán afectados.
                          </p>
                        </div>
                        <div className="flex gap-3 pt-2">
                          <button
                            onClick={() => setShowClearConfirm(false)}
                            className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                          >
                            Cancelar
                          </button>
                          <button
                            onClick={() => {
                              setShowClearConfirm(false);
                              onClearAttempts();
                            }}
                            className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer"
                          >
                            Sí, Borrar Historial
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>

            {totalAttempts === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs space-y-2">
                <Clock className="w-8 h-8 text-slate-300 mx-auto" />
                <p>No has guardado intentos todavía. ¡Rinde un simulador de examen para empezar!</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs md:text-sm">
                  <thead>
                    <tr className="bg-slate-100/50 text-slate-500 uppercase tracking-wider text-[10px] font-bold border-b border-slate-100">
                      <th className="px-5 py-3">Fecha</th>
                      <th className="px-5 py-3">Rango</th>
                      <th className="px-5 py-3">Puntaje</th>
                      <th className="px-5 py-3 text-right">Aciertos</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {attempts.slice().reverse().map((att) => {
                      let statusBadge = "bg-rose-50 text-rose-700 border-rose-100";
                      if (att.score >= 90) statusBadge = "bg-emerald-50 text-emerald-700 border-emerald-100";
                      else if (att.score >= 70) statusBadge = "bg-indigo-50 text-indigo-700 border-indigo-100";

                      return (
                        <tr key={att.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-5 py-3 font-mono text-slate-500">
                            {new Date(att.date).toLocaleDateString()} {new Date(att.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </td>
                          <td className="px-5 py-3 font-semibold uppercase text-[11px]">
                            {att.dimension === 'both' ? 'Ambas' : `Dim. ${att.dimension}`}
                          </td>
                          <td className="px-5 py-3">
                            <span className={`px-2 py-0.5 rounded border text-[11px] font-bold font-mono ${statusBadge}`}>
                              {att.score}%
                            </span>
                          </td>
                          <td className="px-5 py-3 text-right font-mono text-slate-600">
                            {att.correctCount} / {att.totalCount}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Saved Materials (Notes & Bookmarks Summary) */}
        <div className="space-y-6">
          {/* Saved Bookmarks List */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5 space-y-4">
            <h4 className="font-serif font-bold text-slate-800 text-sm md:text-base flex items-center gap-1.5">
              <BookmarkCheck className="w-5 h-5 text-amber-500" />
              Tus Favoritos ({bookmarkedQuestions.length})
            </h4>

            {bookmarkedQuestions.length === 0 ? (
              <p className="text-slate-400 text-xs leading-relaxed">
                Marca preguntas con la estrella en la Guía de Estudio o en el Simulador para guardarlas aquí para revisión rápida.
              </p>
            ) : (
              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                {bookmarkedQuestions.map(q => (
                  <button
                    key={q.id}
                    onClick={() => onNavigateToQuestion(q.id)}
                    className="w-full text-left p-3 bg-slate-50 hover:bg-indigo-50/40 rounded-xl border border-slate-100 hover:border-indigo-200/50 transition-all text-xs flex justify-between items-center gap-2 group cursor-pointer"
                  >
                    <div className="truncate flex-1">
                      <span className="font-mono text-[10px] text-slate-400 font-bold mr-1.5">P.{q.id}</span>
                      <span className="text-slate-700 font-medium group-hover:text-indigo-900">{q.questionText}</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Custom Notes Hub */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5 space-y-4">
            <h4 className="font-serif font-bold text-slate-800 text-sm md:text-base flex items-center gap-1.5">
              <PenTool className="w-5 h-5 text-indigo-500" />
              Guía de Estudio Personal ({questionsWithNotes.length})
            </h4>

            {questionsWithNotes.length === 0 ? (
              <p className="text-slate-400 text-xs leading-relaxed">
                Escribe notas de estudio dentro de las preguntas reveladas en la Guía de Estudio para armar tu propio resumen.
              </p>
            ) : (
              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
                {questionsWithNotes.map(q => (
                  <div key={q.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs space-y-1.5">
                    <div className="flex justify-between items-center">
                      <button
                        onClick={() => onNavigateToQuestion(q.id)}
                        className="font-mono font-bold text-[10px] text-indigo-600 hover:underline cursor-pointer"
                      >
                        Caso P.{q.id} ({q.category})
                      </button>
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Correcta: {q.correctLetter}</span>
                    </div>
                    <p className="text-slate-500 italic text-[11px] leading-relaxed line-clamp-2">
                      &quot;{q.questionText}&quot;
                    </p>
                    <div className="bg-white border border-slate-200 rounded p-2 text-indigo-700 font-medium italic leading-relaxed text-[11px]">
                      {stats[q.id]?.userNote}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
