import React, { useState } from 'react';
import { Award, BookOpen, Clock, Layers, AlertTriangle } from 'lucide-react';

interface HeaderProps {
  totalPracticed: number;
  totalCorrect: number;
  overallAccuracy: number;
  onResetStats: () => void;
}

export default function Header({ totalPracticed, totalCorrect, overallAccuracy, onResetStats }: HeaderProps) {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  return (
    <header className="bg-[#1E293B] text-white rounded-2xl p-6 md:p-8 shadow-xl border border-slate-700/50 relative overflow-hidden" id="app-header">
      {/* Decorative gradient overlay */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative z-10">
        <div>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-300 mb-3 border border-indigo-500/30">
            <Layers className="w-3 h-3 text-indigo-300" /> Cuestionario de Preparación
          </span>
          <h1 className="text-3xl md:text-4xl font-serif font-bold tracking-tight text-white leading-tight">
            Soluciones Educativas
          </h1>
          <p className="text-slate-300 mt-1.5 text-sm md:text-base max-w-xl font-sans">
            Simulador interactivo para docentes en preparación de la evaluación nacional. 
            Domina las dimensiones de responsabilidad y socioemocionales.
          </p>
        </div>

        <div className="flex flex-wrap gap-4 w-full md:w-auto">
          {/* Quick Stat: Practicadas */}
          <div className="bg-slate-800/60 backdrop-blur-sm border border-slate-700/50 rounded-xl px-4 py-3 min-w-[120px] flex-1 md:flex-none">
            <div className="text-xs text-slate-400 flex items-center gap-1 mb-0.5 font-sans">
              <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
              <span>Contestados</span>
            </div>
            <div className="text-2xl font-mono font-bold text-white">
              {totalPracticed}
            </div>
          </div>

          {/* Quick Stat: Precisión */}
          <div className="bg-slate-800/60 backdrop-blur-sm border border-slate-700/50 rounded-xl px-4 py-3 min-w-[120px] flex-1 md:flex-none">
            <div className="text-xs text-slate-400 flex items-center gap-1 mb-0.5 font-sans">
              <Award className="w-3.5 h-3.5 text-indigo-400" />
              <span>Precisión</span>
            </div>
            <div className="text-2xl font-mono font-bold text-indigo-300">
              {overallAccuracy}%
            </div>
          </div>

          <div className="flex items-end w-full md:w-auto">
            <button
              onClick={() => setShowResetConfirm(true)}
              className="w-full md:w-auto text-xs text-slate-400 hover:text-rose-400 transition-colors py-2 px-3 border border-slate-700 hover:border-rose-500/30 rounded-lg hover:bg-rose-500/5 cursor-pointer"
              title="Reiniciar progreso"
            >
              Reiniciar Progreso
            </button>
          </div>
        </div>
      </div>

      {/* Custom Confirmation Modal for Resetting Progress */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in" id="reset-confirm-modal">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={() => setShowResetConfirm(false)}
          />
          {/* Content Card */}
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 relative z-10 space-y-4 text-slate-900">
            <div className="w-12 h-12 bg-rose-50 rounded-full flex items-center justify-center text-rose-500 mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1.5">
              <h4 className="font-serif font-bold text-lg text-slate-800">¿Reiniciar Todo el Progreso?</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Esta acción <strong className="text-rose-600 font-bold">eliminará de forma permanente</strong> todo tu historial de exámenes simulados, tus preguntas guardadas en favoritos y tus notas de la Guía de Estudio. No se puede deshacer.
              </p>
            </div>
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  setShowResetConfirm(false);
                  onResetStats();
                }}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer"
              >
                Sí, Reiniciar Todo
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
