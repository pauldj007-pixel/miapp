import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Question, ExamAttempt, QuestionStats } from '../types';
import { Timer, Award, AlertTriangle, ArrowLeft, ArrowRight, RotateCcw, CheckCircle, XCircle, ChevronRight, Bookmark, BookmarkCheck, BookOpen, BarChart2, Lightbulb, ClipboardList, Brain, Shield, Sparkles } from 'lucide-react';

interface SimulatorProps {
  questions: Question[];
  stats: { [id: number]: QuestionStats };
  onToggleFavorite: (id: number) => void;
  onRecordAttempt: (attempt: ExamAttempt) => void;
}

export default function Simulator({ questions, stats, onToggleFavorite, onRecordAttempt }: SimulatorProps) {
  // Exam States
  const [examActive, setExamActive] = useState<boolean>(false);
  const [examFinished, setExamFinished] = useState<boolean>(false);

  // Configuration States
  const [selectedDimension, setSelectedDimension] = useState<2 | 3 | 'both'>('both');
  const [questionCount, setQuestionCount] = useState<number>(20);
  const [useTimer, setUseTimer] = useState<boolean>(true);

  // Session States
  const [sessionQuestions, setSessionQuestions] = useState<Question[]>([]);
  const [currentIdx, setCurrentIndex] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<{ [id: number]: 'A' | 'B' | 'C' | 'D' }>({});
  const [timeLeft, setTimeLeft] = useState<number>(0); // in seconds
  const [timeSpent, setTimeSpent] = useState<number>(0); // in seconds
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);

  // Timer reference
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Generate randomized questions for the exam session
  const handleStartExam = () => {
    // Filter questions by dimension
    let pool = [...questions];
    if (selectedDimension !== 'both') {
      pool = pool.filter(q => q.dimension === selectedDimension);
    }

    // Shuffle pool
    const shuffled = pool.sort(() => Math.random() - 0.5);
    
    // Slice to desired size
    const finalSelection = shuffled.slice(0, Math.min(questionCount, shuffled.length));

    setSessionQuestions(finalSelection);
    setCurrentIndex(0);
    setUserAnswers({});
    setExamActive(true);
    setExamFinished(false);
    setTimeSpent(0);

    // Standard time: 90 minutes for dimension 3, 45 minutes for dimension 2
    if (useTimer) {
      if (selectedDimension === 3) {
        setTimeLeft(90 * 60); // 90 minutes
      } else if (selectedDimension === 2) {
        setTimeLeft(45 * 60); // 45 minutes
      } else {
        setTimeLeft(135 * 60); // 135 minutes for both
      }
    } else {
      setTimeLeft(0);
    }
  };

  // Timer Tick Side-Effect
  useEffect(() => {
    if (examActive && !examFinished) {
      timerRef.current = setInterval(() => {
        setTimeSpent(prev => prev + 1);

        if (useTimer) {
          setTimeLeft(prev => {
            if (prev <= 1) {
              clearInterval(timerRef.current!);
              handleFinishExam();
              return 0;
            }
            return prev - 1;
          });
        }
      }, 1000);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [examActive, examFinished, useTimer]);

  const handleSelectAnswer = (letter: 'A' | 'B' | 'C' | 'D') => {
    const activeQ = sessionQuestions[currentIdx];
    setUserAnswers(prev => ({ ...prev, [activeQ.id]: letter }));
  };

  const handleFinishExam = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setExamFinished(true);
    setExamActive(false);

    // Calculate score
    let correct = 0;
    sessionQuestions.forEach(q => {
      if (userAnswers[q.id] === q.correctLetter) {
        correct++;
      }
    });

    const scorePct = Math.round((correct / sessionQuestions.length) * 100);

    // Log the exam attempt
    const attempt: ExamAttempt = {
      id: Math.random().toString(36).substring(2, 9),
      date: new Date().toISOString(),
      dimension: selectedDimension,
      score: scorePct,
      correctCount: correct,
      totalCount: sessionQuestions.length,
      timeSpentSeconds: timeSpent,
      completed: true,
      answers: userAnswers
    };

    onRecordAttempt(attempt);
  };

  const handleRestart = () => {
    setExamActive(false);
    setExamFinished(false);
    setSessionQuestions([]);
    setUserAnswers({});
    setCurrentIndex(0);
  };

  // Format Time left display (MM:SS)
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  // Category statistics of current finished exam session
  const categoryStats = useMemo(() => {
    if (!examFinished) return [];
    
    const map: { [cat: string]: { total: number; correct: number } } = {};
    sessionQuestions.forEach(q => {
      if (!map[q.category]) {
        map[q.category] = { total: 0, correct: 0 };
      }
      map[q.category].total++;
      if (userAnswers[q.id] === q.correctLetter) {
        map[q.category].correct++;
      }
    });

    return Object.entries(map).map(([name, data]) => ({
      name,
      percentage: Math.round((data.correct / data.total) * 100),
      ...data
    })).sort((a, b) => b.percentage - a.percentage);
  }, [examFinished, sessionQuestions, userAnswers]);

  // Results Messages based on percentage
  const feedbackMessage = useMemo(() => {
    const correctCount = sessionQuestions.filter(q => userAnswers[q.id] === q.correctLetter).length;
    const pct = Math.round((correctCount / sessionQuestions.length) * 100) || 0;

    if (pct >= 90) {
      return {
        title: "¡Excelente Nivel, Colega!",
        desc: "Has demostrado un dominio sobresaliente de los temas de evaluación. Tu razonamiento pedagógico y asertividad emocional están listos para la prueba.",
        color: "text-emerald-600 bg-emerald-50 border-emerald-200"
      };
    } else if (pct >= 70) {
      return {
        title: "¡Buen Progreso!",
        desc: "Tienes bases sólidas en la mayoría de criterios. Te sugerimos revisar las preguntas falladas en la lista inferior y repasar los distractores en la Guía de Estudio.",
        color: "text-indigo-600 bg-indigo-50 border-indigo-200"
      };
    } else {
      return {
        title: "Necesitas Reforzar",
        desc: "Hay conceptos clave de DUA, protocolos del DECE o autorregulación que requieren mayor revisión. Utiliza la Guía de Estudio por temas para repasar detenidamente.",
        color: "text-amber-600 bg-amber-50 border-amber-200"
      };
    }
  }, [examFinished, sessionQuestions, userAnswers]);

  // Comprehensive EVD0 26 Ecuador Psychological and Socioemotional profile calculation
  const psychologicalProfile = useMemo(() => {
    if (!examFinished || sessionQuestions.length === 0) return null;

    // Define categories for each psychological and socioemotional trait
    const traits = [
      {
        id: 'estabilidad',
        name: 'Estabilidad Emocional y Auto-regulación',
        description: 'Capacidad para mantener la calma bajo presión, regular las emociones ante conductas desafiantes y evitar el agotamiento (burnout) docente.',
        keywords: ['autorregulación', 'emociones', 'estrés', 'bienestar', 'emocional', 'contención'],
        dimension: 3,
        score: 0,
        total: 0,
        correct: 0,
      },
      {
        id: 'resolucion',
        name: 'Resolución de Conflictos y Liderazgo Asertivo',
        description: 'Habilidad para mediar disputas escolares con empatía, aplicar medidas restaurativas y comunicarse asertivamente con la comunidad educativa.',
        keywords: ['resolución de conflictos', 'asertividad', 'relación', 'liderazgo', 'comunicación', 'conflicto'],
        dimension: 3,
        score: 0,
        total: 0,
        correct: 0,
      },
      {
        id: 'inclusion',
        name: 'Sensibilidad Inclusiva y Empatía Pedagógica',
        description: 'Dominio de los principios del Diseño Universal para el Aprendizaje (DUA), adaptaciones curriculares y equidad educativa según estándares del MinEduc.',
        keywords: ['inclusión', 'equidad', 'diversidad', 'dua', 'empatía', 'inclusivo'],
        dimension: 2,
        score: 0,
        total: 0,
        correct: 0,
      },
      {
        id: 'etica',
        name: 'Deontología Docente y Ética Profesional (LOEI)',
        description: 'Alineación con la legislación educativa del Ecuador (LOEI), rutas y protocolos de protección de derechos de niños, niñas y adolescentes.',
        keywords: ['deontología', 'legislación', 'ética', 'responsabilidad', 'protocolos', 'loei', 'ruta'],
        dimension: 2,
        score: 0,
        total: 0,
        correct: 0,
      }
    ];

    // Classify session questions into traits
    sessionQuestions.forEach(q => {
      const qTextLower = q.questionText.toLowerCase();
      const qCatLower = q.category.toLowerCase();
      const isCorrect = userAnswers[q.id] === q.correctLetter;

      let matched = false;
      traits.forEach(trait => {
        // Match by keyword in category or text
        const matchesKeyword = trait.keywords.some(keyword => 
          qCatLower.includes(keyword) || qTextLower.includes(keyword)
        );
        // Also fallback to dimension if not matched specifically to balance numbers
        if (matchesKeyword || (!matched && q.dimension === trait.dimension)) {
          trait.total++;
          if (isCorrect) trait.correct++;
          matched = true;
        }
      });
    });

    // Compute scores and qualitative feedback
    const evaluatedTraits = traits.map(trait => {
      // If no questions fell here, fallback safely
      const percentage = trait.total > 0 ? Math.round((trait.correct / trait.total) * 100) : 75;
      
      let level: 'Excelente' | 'Apto y Confiable' | 'Requiere Refuerzo' = 'Apto y Confiable';
      let statusColor = 'text-indigo-700 bg-indigo-50 border border-indigo-100';
      let barColor = 'bg-indigo-600';
      let details = '';

      if (percentage >= 90) {
        level = 'Excelente';
        statusColor = 'text-emerald-700 bg-emerald-50 border border-emerald-100';
        barColor = 'bg-emerald-500';
        if (trait.id === 'estabilidad') {
          details = 'Posees un excelente control de impulsos. Respondes con templanza, priorizando la respiración y la calma mental ante crisis del alumnado.';
        } else if (trait.id === 'resolucion') {
          details = 'Tu liderazgo es asertivo y democrático. Prefieres la mediación restaurativa por sobre los castigos punitivos de la vieja escuela.';
        } else if (trait.id === 'inclusion') {
          details = 'Integras con naturalidad el Diseño Universal para el Aprendizaje (DUA). Entiendes que la inclusión es un derecho irrenunciable.';
        } else {
          details = 'Altamente alineado con el marco legal y deontológico (LOEI/MinEduc). Sabes exactamente cuándo y cómo activar rutas de protección.';
        }
      } else if (percentage >= 70) {
        level = 'Apto y Confiable';
        statusColor = 'text-indigo-700 bg-indigo-50 border border-indigo-100';
        barColor = 'bg-indigo-600';
        if (trait.id === 'estabilidad') {
          details = 'Tienes un buen manejo del estrés. Sin embargo, en situaciones de alta presión puedes rozar el desgaste emocional. Recuerda delegar.';
        } else if (trait.id === 'resolucion') {
          details = 'Logras acuerdos satisfactorios mediante la empatía, pero debes asegurar que el proceso sea 100% reparador y sistemático.';
        } else if (trait.id === 'inclusion') {
          details = 'Reconoces la diversidad de ritmos de aprendizaje, aunque necesitas repasar pautas específicas de DUA para personalizar la evaluación.';
        } else {
          details = 'Conoces las normativas, pero te sugerimos revisar más a fondo las rutas de actuación urgente del DECE en violencia escolar.';
        }
      } else {
        level = 'Requiere Refuerzo';
        statusColor = 'text-amber-700 bg-amber-50 border border-amber-200';
        barColor = 'bg-amber-500';
        if (trait.id === 'estabilidad') {
          details = 'Tus respuestas tienden a soluciones reactivas u omiten la contención inicial. Trabaja en tu autocompasión y manejo de crisis.';
        } else if (trait.id === 'resolucion') {
          details = 'Sueles delegar de inmediato la resolución de conflictos a terceros (rectoría, inspectores) en lugar de asumir la mediación inicial formativa.';
        } else if (trait.id === 'inclusion') {
          details = 'Aún persisten sesgos de segregación pedagógica o asimilación. Es vital asimilar que el aula se adapta al alumno, no al revés.';
        } else {
          details = '¡Atención! Es crítico dominar la LOEI y las rutas del DECE. Omitir reportes de presuntos abusos acarrea serias responsabilidades legales.';
        }
      }

      return {
        ...trait,
        percentage,
        level,
        statusColor,
        barColor,
        details
      };
    });

    // Calculate Overall Psychological Suitability Index
    const correctCount = sessionQuestions.filter(q => userAnswers[q.id] === q.correctLetter).length;
    const totalCount = sessionQuestions.length;
    const scorePct = Math.round((correctCount / totalCount) * 100) || 0;

    let overallVerdict = 'Apto - Nivel Sobresaliente';
    let verdictDesc = 'Demuestras un perfil psicológico con madurez emocional óptima, alta resiliencia y pleno alineamiento con las políticas de inclusión del Ecuador. Tu criterio docente ante dilemas éticos y socioemocionales cumple con creces las expectativas ministeriales para la evaluación EVD0 26.';
    let verdictColor = 'text-emerald-800 bg-emerald-50 border-emerald-200';

    if (scorePct >= 90) {
      overallVerdict = 'Apto - Nivel Sobresaliente';
      verdictColor = 'text-emerald-800 bg-emerald-50 border-emerald-200';
    } else if (scorePct >= 70) {
      overallVerdict = 'Apto - Nivel Confiable';
      verdictDesc = 'Tu perfil denota equilibrio y capacidad de respuesta empática, apto para ejercer la docencia con responsabilidad profesional. Se recomiendan lecturas puntuales sobre las pautas del DUA y protocolos de protección de derechos para pulir tu puntaje al máximo.';
      verdictColor = 'text-indigo-800 bg-indigo-50 border-indigo-200';
    } else {
      overallVerdict = 'Requiere Fortalecimiento Temprano';
      verdictDesc = 'El perfil psicológico refleja decisiones que podrían percibirse como reactivas, punitivas o desalineadas con la LOEI. Es fundamental profundizar de inmediato en el marco socioemocional y ético regulado por el MinEduc para el correcto abordaje de dilemas prácticos.';
      verdictColor = 'text-amber-800 bg-amber-50 border-amber-200';
    }

    return {
      traits: evaluatedTraits,
      overallVerdict,
      verdictDesc,
      verdictColor,
      scorePct
    };
  }, [examFinished, sessionQuestions, userAnswers]);

  const activeQuestion = sessionQuestions[currentIdx];

  // RENDER SETUP PARAMETERS
  if (!examActive && !examFinished) {
    return (
      <div className="bg-white border border-slate-200 rounded-2xl p-6 md:p-8 shadow-sm max-w-2xl mx-auto space-y-6" id="simulator-config-card">
        <div className="text-center space-y-1">
          <Award className="w-12 h-12 text-indigo-600 mx-auto mb-2" />
          <h3 className="font-serif font-bold text-slate-800 text-xl md:text-2xl">
            Simulador de Examen Docente
          </h3>
          <p className="text-slate-500 text-sm leading-relaxed max-w-md mx-auto">
            Configura una simulación de examen aleatorio basada en la rúbrica oficial.
          </p>
        </div>

        <div className="space-y-4 pt-2">
          {/* Dimension Toggle */}
          <div className="space-y-1.5">
            <label className="text-slate-700 font-bold text-xs uppercase tracking-wider">
              1. Selecciona la Dimensión de Evaluación
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedDimension('both')}
                className={`p-3 rounded-xl border text-xs font-semibold text-center transition-all ${
                  selectedDimension === 'both'
                    ? 'bg-slate-900 border-slate-900 text-white shadow-sm font-bold'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                Ambas Unidas (163 q)
              </button>
              <button
                type="button"
                onClick={() => setSelectedDimension(2)}
                className={`p-3 rounded-xl border text-xs font-semibold text-center transition-all ${
                  selectedDimension === 2
                    ? 'bg-slate-900 border-slate-900 text-white shadow-sm font-bold'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                Responsabilidad (Dim. 2)
              </button>
              <button
                type="button"
                onClick={() => setSelectedDimension(3)}
                className={`p-3 rounded-xl border text-xs font-semibold text-center transition-all ${
                  selectedDimension === 3
                    ? 'bg-slate-900 border-slate-900 text-white shadow-sm font-bold'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                Socioemocionales (Dim. 3)
              </button>
            </div>
          </div>

          {/* Question Limit selector */}
          <div className="space-y-1.5">
            <label className="text-slate-700 font-bold text-xs uppercase tracking-wider">
              2. Cantidad de Preguntas
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[10, 20, 50, 110].map(count => (
                <button
                  key={count}
                  type="button"
                  onClick={() => setQuestionCount(count)}
                  className={`py-2 px-3 rounded-xl border text-xs font-semibold text-center transition-all ${
                    questionCount === count
                      ? 'bg-indigo-600 border-indigo-600 text-white shadow-md font-bold'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {count === 110 ? 'Todas' : `${count} q`}
                </button>
              ))}
            </div>
          </div>

          {/* Use Timer toggle */}
          <div className="flex justify-between items-center bg-slate-50 p-4 border border-slate-100 rounded-xl">
            <div>
              <h5 className="text-slate-800 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Timer className="w-4 h-4 text-indigo-600" />
                Habilitar Temporizador
              </h5>
              <p className="text-slate-400 text-[11px] leading-relaxed mt-0.5 max-w-sm">
                Asigna 90 minutos para la Dimensión 3 y 45 minutos para la Dimensión 2, emulando los tiempos oficiales del examen.
              </p>
            </div>
            <button
              onClick={() => setUseTimer(!useTimer)}
              className={`w-12 h-6 rounded-full p-1 transition-all ${
                useTimer ? 'bg-indigo-600' : 'bg-slate-300'
              }`}
            >
              <div className={`w-4 h-4 bg-white rounded-full transition-transform ${
                useTimer ? 'translate-x-6' : 'translate-x-0'
              }`} />
            </button>
          </div>
        </div>

        <button
          onClick={handleStartExam}
          className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3.5 px-4 rounded-xl shadow-md transition-all text-sm md:text-base flex items-center justify-center gap-2"
        >
          Iniciar Simulación de Examen
          <ArrowRight className="w-4.5 h-4.5" />
        </button>
      </div>
    );
  }

  // RENDER ACTIVE EXAM
  if (examActive && activeQuestion) {
    const selectedAns = userAnswers[activeQuestion.id];
    const isFav = stats[activeQuestion.id]?.isFavorite || false;
    const progressPct = Math.round(((currentIdx + 1) / sessionQuestions.length) * 100);

    // Warning color trigger for timer
    let timerColor = 'text-slate-700 bg-slate-100';
    if (useTimer) {
      if (timeLeft <= 30) {
        timerColor = 'text-rose-600 bg-rose-50 border border-rose-200 animate-pulse';
      } else if (timeLeft <= 120) {
        timerColor = 'text-amber-600 bg-amber-50 border border-amber-200';
      }
    }

    return (
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden space-y-6" id="active-exam-container">
        {/* Header Bar */}
        <div className="px-6 py-4 bg-[#1E293B] text-white flex flex-wrap justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-indigo-400" />
            <span className="font-serif font-bold text-sm md:text-base">
              Examen en Curso
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* Timer component */}
            {useTimer && (
              <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-bold ${timerColor}`}>
                <Timer className="w-4 h-4" />
                <span>{formatTime(timeLeft)}</span>
              </div>
            )}

            <button
              onClick={() => onToggleFavorite(activeQuestion.id)}
              className={`p-1.5 rounded-lg border border-slate-700 transition-all ${
                isFav 
                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Bookmark className="w-4 h-4 fill-current" />
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="px-6 md:px-8">
          <div className="flex justify-between text-xs text-slate-500 mb-1.5 font-semibold">
            <span>Pregunta {currentIdx + 1} de {sessionQuestions.length}</span>
            <span>{progressPct}% Completado</span>
          </div>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className="bg-indigo-600 h-full transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>

        {/* Question Panel */}
        <div className="px-6 md:px-8 pb-6 space-y-6">
          <div className="bg-slate-50/50 border border-slate-100 p-5 md:p-6 rounded-xl space-y-2">
            <div className="flex gap-2">
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                activeQuestion.dimension === 2 ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'
              }`}>
                Dimensión {activeQuestion.dimension}
              </span>
              <span className="text-slate-400 text-[10px] font-bold">•</span>
              <span className="text-slate-500 text-[10px] font-bold uppercase tracking-wider">
                {activeQuestion.category}
              </span>
            </div>
            <h4 className="font-sans font-medium text-slate-800 text-sm md:text-base leading-relaxed">
              {activeQuestion.questionText}
            </h4>
          </div>

          {/* Interactive Options list */}
          <div className="space-y-2.5">
            {activeQuestion.options.map(opt => {
              const isSelected = selectedAns === opt.letter;
              return (
                <button
                  key={opt.letter}
                  onClick={() => handleSelectAnswer(opt.letter)}
                  className={`w-full p-4 rounded-xl border text-left text-xs md:text-sm flex items-start gap-3.5 transition-all ${
                    isSelected
                      ? 'bg-indigo-50 border-indigo-500 text-indigo-900 ring-2 ring-indigo-500/10'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50/50 hover:border-slate-300'
                  }`}
                >
                  <span className={`w-6 h-6 shrink-0 rounded-full flex items-center justify-center font-mono font-bold text-xs ${
                    isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {opt.letter}
                  </span>
                  <span className="leading-relaxed mt-0.5">{opt.text}</span>
                </button>
              );
            })}
          </div>

          {/* Navigation Controls */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row justify-between gap-3">
            <div className="flex gap-2 w-full sm:w-auto">
              <button
                disabled={currentIdx === 0}
                onClick={() => setCurrentIndex(prev => prev - 1)}
                className="flex-1 sm:flex-initial px-4 py-2.5 border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-semibold rounded-xl disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Anterior</span>
              </button>

              <button
                disabled={currentIdx === sessionQuestions.length - 1}
                onClick={() => setCurrentIndex(prev => prev + 1)}
                className="flex-1 sm:flex-initial px-4 py-2.5 border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-semibold rounded-xl disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-1.5"
              >
                <span>Siguiente</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={() => {
                setShowConfirmModal(true);
              }}
              className="w-full sm:w-auto px-5 py-2.5 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl shadow-md hover:shadow-lg transition-all text-center text-sm cursor-pointer"
            >
              Finalizar y Calificar
            </button>
          </div>
        </div>

        {/* CUSTOM CONFIRMATION DIALOG MODAL (State-based, avoiding blocked window.confirm in sandbox) */}
        {showConfirmModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4" id="confirm-modal-overlay">
            {/* Backdrop */}
            <div 
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
              onClick={() => setShowConfirmModal(false)}
            />
            {/* Modal Content Card */}
            <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 relative z-10 space-y-4" id="confirm-modal-content">
              <div className="w-12 h-12 bg-amber-50 rounded-full flex items-center justify-center text-amber-500 mx-auto">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div className="text-center space-y-1.5">
                <h4 className="text-slate-800 font-serif font-bold text-lg">¿Finalizar Simulación de Examen?</h4>
                {sessionQuestions.length - Object.keys(userAnswers).length > 0 ? (
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Tienes <strong className="text-slate-800 font-bold">{sessionQuestions.length - Object.keys(userAnswers).length} preguntas sin responder</strong> de un total de {sessionQuestions.length}. ¿Deseas terminar y calificar de todos modos?
                  </p>
                ) : (
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Has respondido todas las preguntas. ¿Deseas finalizar para generar tu análisis detallado y tu <strong>Perfil Psicológico Docente EVD0 26</strong>?
                  </p>
                )}
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => setShowConfirmModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                >
                  Continuar Respondiendo
                </button>
                <button
                  onClick={() => {
                    setShowConfirmModal(false);
                    handleFinishExam();
                  }}
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer"
                >
                  Sí, Finalizar y Calificar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // RENDER DETAILED REPORT CARD (IF FINISHED)
  if (examFinished) {
    const correctCount = sessionQuestions.filter(q => userAnswers[q.id] === q.correctLetter).length;
    const totalCount = sessionQuestions.length;
    const scorePct = Math.round((correctCount / totalCount) * 100);

    // Color definitions based on score
    let strokeColor = "stroke-amber-500";
    let textColor = "text-amber-600";
    if (scorePct >= 90) {
      strokeColor = "stroke-emerald-500";
      textColor = "text-emerald-500";
    } else if (scorePct >= 70) {
      strokeColor = "stroke-indigo-500";
      textColor = "text-indigo-600";
    }

    return (
      <div className="space-y-6" id="exam-results-container">
        {/* Results Overview Card */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 md:p-8 shadow-sm space-y-6">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="text-center lg:text-left space-y-3 flex-1">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-700 border border-indigo-500/20">
                Resultado de Simulación
              </span>
              <h3 className="font-serif font-bold text-slate-800 text-2xl md:text-3xl">
                {feedbackMessage.title}
              </h3>
              <p className="text-slate-500 text-sm leading-relaxed max-w-xl">
                {feedbackMessage.desc}
              </p>
            </div>

            {/* Circular Gauge */}
            <div className="relative w-36 h-36 shrink-0 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="72"
                  cy="72"
                  r="62"
                  className="stroke-slate-100 fill-none"
                  strokeWidth="12"
                />
                <circle
                  cx="72"
                  cy="72"
                  r="62"
                  className={`${strokeColor} fill-none transition-all duration-1000`}
                  strokeWidth="12"
                  strokeDasharray={2 * Math.PI * 62}
                  strokeDashoffset={2 * Math.PI * 62 * (1 - scorePct / 100)}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute flex flex-col items-center justify-center text-center">
                <span className={`text-3xl font-mono font-bold ${textColor}`}>{scorePct}%</span>
                <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Aciertos</span>
              </div>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-3 gap-3 border-t border-slate-100 pt-6">
            <div className="text-center">
              <span className="block text-slate-400 text-xs">Aciertos</span>
              <strong className="text-slate-800 text-lg md:text-xl font-mono">{correctCount} / {totalCount}</strong>
            </div>
            <div className="text-center border-x border-slate-100">
              <span className="block text-slate-400 text-xs">Tiempo</span>
              <strong className="text-slate-800 text-lg md:text-xl font-mono">{formatTime(timeSpent)}</strong>
            </div>
            <div className="text-center">
              <span className="block text-slate-400 text-xs font-sans">Dimensión</span>
              <strong className="text-slate-800 text-xs font-semibold uppercase">
                {selectedDimension === 'both' ? 'Ambas' : `Dim. ${selectedDimension}`}
              </strong>
            </div>
          </div>
        </div>

        {/* PERFIL PSICOLÓGICO Y SOCIOEMOCIONAL DOCENTE - EVD0 26 ECUADOR */}
        {psychologicalProfile && (
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden" id="psychological-profile-card">
            {/* Header with distinct professional styling */}
            <div className="bg-[#1E293B] text-white p-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
              <div className="flex items-center gap-3 relative z-10">
                <div className="w-10 h-10 bg-indigo-600/30 border border-indigo-400/20 rounded-xl flex items-center justify-center text-indigo-300">
                  <Brain className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider block">Análisis Diagnóstico Especializado</span>
                  <h4 className="font-serif font-bold text-lg md:text-xl text-white">Perfil Psicológico y Socioemocional Docente</h4>
                </div>
              </div>
              <p className="text-slate-300 text-xs mt-2.5 max-w-2xl leading-relaxed">
                Este dictamen evalúa tu madurez socioemocional, asertividad relacional, control del estrés y apego normativo según los estándares e indicadores psicológicos de la evaluación nacional **EVD0 26** del Ministerio de Educación del Ecuador.
              </p>
            </div>

            <div className="p-6 md:p-8 space-y-6">
              {/* Overall Verdict Banner */}
              <div className={`p-5 rounded-2xl border ${psychologicalProfile.verdictColor} space-y-2`}>
                <div className="flex items-center gap-2.5">
                  <Shield className="w-5 h-5 shrink-0" />
                  <span className="text-xs font-bold uppercase tracking-wider">Dictamen de Aptitud Psicológica:</span>
                  <strong className="text-sm font-extrabold ml-auto">{psychologicalProfile.overallVerdict}</strong>
                </div>
                <p className="text-xs md:text-sm leading-relaxed">
                  {psychologicalProfile.verdictDesc}
                </p>
              </div>

              {/* Traits Breakdown Grid */}
              <div className="space-y-5">
                <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Desglose de Rasgos Evaluados</h5>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {psychologicalProfile.traits.map(trait => (
                    <div key={trait.id} className="bg-slate-50/50 border border-slate-100 rounded-xl p-4 md:p-5 flex flex-col justify-between space-y-3">
                      <div className="space-y-1.5">
                        <div className="flex justify-between items-start gap-2">
                          <h6 className="font-sans font-semibold text-slate-800 text-xs leading-snug">{trait.name}</h6>
                          <span className={`px-2 py-0.5 rounded-full font-mono font-bold text-[9px] border shrink-0 ${trait.statusColor}`}>
                            {trait.percentage}%
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed">{trait.description}</p>
                      </div>
                      
                      <div className="space-y-2 pt-1">
                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                          <div className={`${trait.barColor} h-full transition-all duration-500`} style={{ width: `${trait.percentage}%` }} />
                        </div>
                        <p className="text-[11px] text-slate-600 font-medium leading-relaxed italic bg-white p-2.5 rounded border border-slate-100">
                          {trait.details}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommendations and psychological keys for EVD0 26 */}
              <div className="border-t border-slate-100 pt-6 space-y-4">
                <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-indigo-500" />
                  Recomendaciones Clave para la Prueba EVD0 26 Ecuador
                </h5>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-sans">
                  <div className="p-4 bg-indigo-50/40 rounded-xl border border-indigo-100/30 space-y-1">
                    <span className="font-bold text-indigo-600 text-[11px] uppercase tracking-wider block">1. Evita Respuestas Extremas o Punibles</span>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      El evaluador psicológico de la LOEI castiga severamente las decisiones reactivas, gritar, sancionar unilateralmente o suspender clases sin aplicar el protocolo formativo.
                    </p>
                  </div>
                  <div className="p-4 bg-indigo-50/40 rounded-xl border border-indigo-100/30 space-y-1">
                    <span className="font-bold text-indigo-600 text-[11px] uppercase tracking-wider block">2. Aplica Rutas de Actuación (DECE)</span>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      En casos de presunta vulneración de derechos o acoso escolar, la única respuesta correcta y ética es activar de inmediato la ruta legal y referir al DECE/Autoridades, jamás resolverlo a solas de forma informal.
                    </p>
                  </div>
                  <div className="p-4 bg-indigo-50/40 rounded-xl border border-indigo-100/30 space-y-1">
                    <span className="font-bold text-indigo-600 text-[11px] uppercase tracking-wider block">3. Estabilidad y Autocuidado Docente</span>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      Acepta que no puedes controlar todo. Ante la presión y la sobrecarga laboral docente, la mejor respuesta es la canalización asertiva y el cuidado de tu propia salud mental.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Strength & Weaknesses Breakdown */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
          <h4 className="font-serif font-bold text-slate-800 text-base md:text-lg flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-indigo-600" />
            Análisis de Desempeño por Tema
          </h4>
          <p className="text-slate-400 text-xs">
            Esta gráfica resalta tus fortalezas y qué temas específicos de la rúbrica nacional requieres profundizar.
          </p>

          <div className="space-y-3.5 pt-2">
            {categoryStats.map(cat => {
              let barColor = "bg-rose-500";
              let badgeColor = "bg-rose-50 text-rose-700 border-rose-100";
              if (cat.percentage >= 90) {
                barColor = "bg-emerald-500";
                badgeColor = "bg-emerald-50 text-emerald-700 border-emerald-100";
              } else if (cat.percentage >= 70) {
                barColor = "bg-indigo-500";
                badgeColor = "bg-indigo-50 text-indigo-700 border-indigo-100";
              }

              return (
                <div key={cat.name} className="space-y-1">
                  <div className="flex justify-between items-center text-xs gap-4">
                    <span className="text-slate-700 font-medium truncate">{cat.name}</span>
                    <span className={`px-2 py-0.5 rounded-full font-mono font-bold text-[10px] border ${badgeColor}`}>
                      {cat.percentage}% ({cat.correct}/{cat.total})
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className={`${barColor} h-full transition-all duration-500`}
                      style={{ width: `${cat.percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Incorrect Answers Review */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
          <div className="px-6 py-4 bg-slate-50 border-b border-slate-100">
            <h4 className="font-serif font-bold text-slate-800 text-base">
              Revisión de Errores e Incorrecciones
            </h4>
            <p className="text-slate-400 text-xs mt-0.5">
              Revisa los casos que fallaste para asimilar la respuesta justificada y perfeccionar tu razonamiento.
            </p>
          </div>

          <div className="divide-y divide-slate-100">
            {sessionQuestions.filter(q => userAnswers[q.id] !== q.correctLetter).length === 0 ? (
              <div className="p-10 text-center space-y-2">
                <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto" />
                <h5 className="font-serif font-bold text-slate-800 text-base">¡Felicidades, examen perfecto!</h5>
                <p className="text-slate-400 text-xs">No has fallado ninguna respuesta en este examen de simulación.</p>
              </div>
            ) : (
              sessionQuestions
                .filter(q => userAnswers[q.id] !== q.correctLetter)
                .map((q, idx) => {
                  const userAnsLetter = userAnswers[q.id];
                  const userAnsText = q.options.find(o => o.letter === userAnsLetter)?.text || "Sin respuesta";
                  const correctAnsText = q.options.find(o => o.letter === q.correctLetter)?.text;

                  return (
                    <div key={q.id} className="p-6 space-y-4">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs font-bold text-rose-500 bg-rose-50 px-2 py-0.5 rounded border border-rose-100">
                          Incorrecta
                        </span>
                        <span className="text-slate-400 text-xs">Pregunta {q.id} • {q.category}</span>
                      </div>

                      <h5 className="font-sans font-medium text-slate-800 text-sm md:text-base leading-relaxed">
                        {q.questionText}
                      </h5>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                        {/* Selected answer */}
                        <div className="bg-rose-50/50 border border-rose-100 rounded-xl p-3.5 space-y-1">
                          <span className="font-semibold text-rose-800 flex items-center gap-1">
                            <XCircle className="w-4 h-4 text-rose-500" /> Tu respuesta seleccionada (Opción {userAnsLetter || 'Ninguna'}):
                          </span>
                          <p className="text-slate-600 leading-relaxed italic">{userAnsText}</p>
                        </div>

                        {/* Correct answer */}
                        <div className="bg-emerald-50/50 border border-emerald-100 rounded-xl p-3.5 space-y-1">
                          <span className="font-semibold text-emerald-800 flex items-center gap-1">
                            <CheckCircle className="w-4 h-4 text-emerald-500" /> Respuesta correcta recomendada (Opción {q.correctLetter}):
                          </span>
                          <p className="text-slate-600 leading-relaxed font-medium italic">{correctAnsText}</p>
                        </div>
                      </div>

                      {q.justification && (
                        <div className="bg-amber-50/40 border border-amber-100 rounded-xl p-4 flex gap-2.5">
                          <Lightbulb className="w-5 h-5 text-amber-500 shrink-0" />
                          <div className="space-y-1 text-xs md:text-sm text-slate-700 leading-relaxed">
                            <strong className="text-slate-800 block">Justificación pedagógica / distractores:</strong>
                            <p>{q.justification}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex gap-3 justify-center">
          <button
            onClick={handleRestart}
            className="px-5 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-md transition-all text-sm flex items-center gap-2"
          >
            <RotateCcw className="w-4.5 h-4.5" />
            <span>Configurar Nuevo Examen</span>
          </button>
        </div>
      </div>
    );
  }

  return null;
}
