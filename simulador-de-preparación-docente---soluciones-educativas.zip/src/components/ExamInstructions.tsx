import React, { useState } from 'react';
import { BookOpen, Camera, ShieldAlert, Monitor, Info, CheckCircle2, ChevronDown, ChevronUp, Clock, HelpCircle, Eye } from 'lucide-react';

export default function ExamInstructions() {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden" id="exam-instructions-container">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center px-6 py-4 bg-slate-50 border-b border-slate-100 text-left hover:bg-slate-100/50 transition-colors"
      >
        <div className="flex items-center gap-2">
          <Info className="w-5 h-5 text-indigo-600" />
          <h3 className="font-serif font-bold text-slate-800 text-base md:text-lg">
            Guía de Estudio y Recomendaciones de Examen (PDF Oficial)
          </h3>
        </div>
        {isOpen ? <ChevronUp className="w-5 h-5 text-slate-500" /> : <ChevronDown className="w-5 h-5 text-slate-500" />}
      </button>

      {isOpen && (
        <div className="p-6 md:p-8 space-y-8">
          {/* Estrategia Recomendada */}
          <div>
            <h4 className="font-serif font-semibold text-slate-900 text-sm md:text-base uppercase tracking-wider mb-4 border-l-4 border-indigo-500 pl-3">
              Estrategia Recomendada de Preparación
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 flex gap-3">
                <span className="font-mono font-bold text-xl text-indigo-600">1</span>
                <div>
                  <h5 className="font-sans font-semibold text-slate-800 text-sm mb-1">Lee cuidadosamente</h5>
                  <p className="text-slate-500 text-xs leading-relaxed">
                    Evita responder con prisa; identifica qué está preguntando realmente el enunciado en cada caso.
                  </p>
                </div>
              </div>

              <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 flex gap-3">
                <span className="font-mono font-bold text-xl text-indigo-600">2</span>
                <div>
                  <h5 className="font-sans font-semibold text-slate-800 text-sm mb-1">Elimina los distractores</h5>
                  <p className="text-slate-500 text-xs leading-relaxed">
                    Descarta primero las opciones que claramente no responden al caso para reducir las posibilidades y afinar tu razonamiento.
                  </p>
                </div>
              </div>

              <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 flex gap-3">
                <span className="font-mono font-bold text-xl text-indigo-600">3</span>
                <div>
                  <h5 className="font-sans font-semibold text-slate-800 text-sm mb-1">Relaciona con tu práctica</h5>
                  <p className="text-slate-500 text-xs leading-relaxed">
                    Muchas preguntas se fundamentan en escenarios reales del trabajo en el aula y de la institución.
                  </p>
                </div>
              </div>

              <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 flex gap-3">
                <span className="font-mono font-bold text-xl text-indigo-600">4</span>
                <div>
                  <h5 className="font-sans font-semibold text-slate-800 text-sm mb-1">Administra el tiempo</h5>
                  <p className="text-slate-500 text-xs leading-relaxed">
                    Si una pregunta genera dudas, continúa con la siguiente y vuelve al final. Mantener la calma es clave del éxito.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Indicaciones de la Plataforma INEVAL */}
          <div className="border-t border-slate-100 pt-6">
            <h4 className="font-serif font-semibold text-slate-900 text-sm md:text-base uppercase tracking-wider mb-4 border-l-4 border-indigo-500 pl-3">
              Indicaciones Generales para el Día del Examen (INEVAL)
            </h4>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Prohibiciones */}
              <div className="bg-rose-50/50 border border-rose-100 rounded-xl p-5 space-y-4">
                <div className="flex items-center gap-2 text-rose-800 font-semibold text-sm">
                  <ShieldAlert className="w-5 h-5 text-rose-500 animate-pulse" />
                  <span>PROHIBICIONES ESTRICTAS</span>
                </div>
                <ul className="space-y-3 text-slate-600 text-xs leading-relaxed">
                  <li className="flex items-start gap-2">
                    <span className="text-rose-500 font-bold">✕</span>
                    <span>
                      <strong>Capturas de pantalla:</strong> Está estrictamente prohibido tomar capturas de pantalla de cualquier sección, pregunta o resultado para proteger la confidencialidad de los reactivos.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-rose-500 font-bold">✕</span>
                    <span>
                      <strong>Salir del navegador:</strong> No cierres la ventana ni salgas del navegador en el que abriste la plataforma. Cualquier salida no autorizada puede invalidar tu sesión o generar errores.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-rose-500 font-bold">✕</span>
                    <span>
                      <strong>Compartir pantalla:</strong> Prohibido compartir la pantalla del dispositivo por herramientas de videollamada, aplicaciones de transmisión o cualquier otro medio.
                    </span>
                  </li>
                </ul>
              </div>

              {/* Recomendaciones */}
              <div className="bg-indigo-50/50 border border-indigo-100 rounded-xl p-5 space-y-4">
                <div className="flex items-center gap-2 text-indigo-900 font-semibold text-sm">
                  <CheckCircle2 className="w-5 h-5 text-indigo-600" />
                  <span>RECOMENDACIONES IMPORTANTES</span>
                </div>
                <ul className="space-y-3 text-slate-600 text-xs leading-relaxed">
                  <li className="flex items-start gap-2">
                    <span className="text-indigo-600 font-bold">✓</span>
                    <span>
                      <strong>Cámara activa:</strong> Mantén la cámara de tu dispositivo activa durante todo el proceso para verificar el desarrollo normal y garantizar la transparencia del trabajo.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-indigo-600 font-bold">✓</span>
                    <span>
                      <strong>Entorno silencioso:</strong> Elige un lugar silencioso y solo. Evita conversar con otras personas ni permanezcas en sitios con ruidos molestos para concentrarte.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-indigo-600 font-bold">✓</span>
                    <span>
                      <strong>Calma y Respiración:</strong> Respira despacio y mantén la calma. La tranquilidad te ayudará a pensar con mayor claridad y responder con seguridad. No te apresures.
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
