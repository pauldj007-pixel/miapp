import React, { useState, useMemo } from 'react';
import { Question, QuestionStats } from '../types';
import { Search, Bookmark, BookmarkCheck, BookOpen, Filter, ArrowRight, Save, Trash, HelpCircle, AlertCircle, CheckCircle2, Eye } from 'lucide-react';

interface StudyGuideProps {
  questions: Question[];
  stats: { [id: number]: QuestionStats };
  onToggleFavorite: (id: number) => void;
  onSaveNote: (id: number, note: string) => void;
}

export default function StudyGuide({ questions, stats, onToggleFavorite, onSaveNote }: StudyGuideProps) {
  // Filters
  const [selectedDimension, setSelectedDimension] = useState<'all' | 2 | 3>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showFavoritesOnly, setShowFavoritesOnly] = useState<boolean>(false);

  // Pagination
  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 1;

  // Active revealed question IDs
  const [revealedIds, setRevealedIds] = useState<{ [id: number]: boolean }>({});

  // Local temporary notes state
  const [tempNotes, setTempNotes] = useState<{ [id: number]: string }>({});

  // Dynamically compute categories list based on dimension
  const categoriesList = useMemo(() => {
    const list = questions
      .filter(q => selectedDimension === 'all' || q.dimension === selectedDimension)
      .map(q => q.category);
    return Array.from(new Set(list)).sort();
  }, [questions, selectedDimension]);

  // Reset category filter if selectedDimension changes and category is no longer valid
  const handleDimensionChange = (dim: 'all' | 2 | 3) => {
    setSelectedDimension(dim);
    setSelectedCategory('all');
    setCurrentPage(1);
  };

  // Filtered questions
  const filteredQuestions = useMemo(() => {
    return questions.filter(q => {
      // Dimension Filter
      if (selectedDimension !== 'all' && q.dimension !== selectedDimension) return false;
      
      // Category Filter
      if (selectedCategory !== 'all' && q.category !== selectedCategory) return false;
      
      // Favorites Filter
      const isFav = stats[q.id]?.isFavorite || false;
      if (showFavoritesOnly && !isFav) return false;

      // Text Search Filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const textMatch = q.questionText.toLowerCase().includes(query);
        const optMatch = q.options.some(opt => opt.text.toLowerCase().includes(query));
        const categoryMatch = q.category.toLowerCase().includes(query);
        if (!textMatch && !optMatch && !categoryMatch) return false;
      }

      return true;
    });
  }, [questions, selectedDimension, selectedCategory, searchQuery, showFavoritesOnly, stats]);

  // Total pages
  const totalPages = Math.ceil(filteredQuestions.length / itemsPerPage) || 1;

  // Paginated questions
  const paginatedQuestions = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredQuestions.slice(start, start + itemsPerPage);
  }, [filteredQuestions, currentPage]);

  const toggleReveal = (id: number) => {
    setRevealedIds(prev => ({ ...prev, [id]: !prev[id] }));
    if (!tempNotes.hasOwnProperty(id)) {
      setTempNotes(prev => ({ ...prev, [id]: stats[id]?.userNote || '' }));
    }
  };

  const handleSaveNote = (id: number) => {
    const noteText = tempNotes[id] || '';
    onSaveNote(id, noteText);
    alert('Anotación guardada correctamente.');
  };

  return (
    <div className="space-y-6" id="study-guide-workspace">
      {/* Search and Filters Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 md:p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h3 className="font-serif font-bold text-slate-800 text-lg flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-indigo-600" />
              Guía de Preguntas ({filteredQuestions.length})
            </h3>
            <p className="text-slate-400 text-xs mt-0.5">
              Navega, filtra y estudia los casos con sus respuestas explicadas.
            </p>
          </div>

          {/* Quick toggle to show bookmarked */}
          <button
            onClick={() => {
              setShowFavoritesOnly(!showFavoritesOnly);
              setCurrentPage(1);
            }}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all border ${
              showFavoritesOnly
                ? 'bg-amber-500/10 text-amber-700 border-amber-500/30'
                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
            }`}
          >
            {showFavoritesOnly ? <BookmarkCheck className="w-4 h-4 text-amber-500" /> : <Bookmark className="w-4 h-4" />}
            <span>{showFavoritesOnly ? 'Ver Todas' : 'Ver Favoritas'}</span>
          </button>
        </div>

        {/* Filters Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          {/* Dimension Selector */}
          <div className="space-y-1">
            <label className="text-slate-500 text-xs font-semibold">Dimensión</label>
            <div className="flex bg-slate-50 p-1 rounded-xl border border-slate-200">
              <button
                onClick={() => handleDimensionChange('all')}
                className={`flex-1 text-center py-1.5 rounded-lg text-xs font-medium transition-all ${
                  selectedDimension === 'all'
                    ? 'bg-white text-slate-800 shadow-sm font-bold'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Todas
              </button>
              <button
                onClick={() => handleDimensionChange(2)}
                className={`flex-1 text-center py-1.5 rounded-lg text-xs font-medium transition-all ${
                  selectedDimension === 2
                    ? 'bg-white text-slate-800 shadow-sm font-bold'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
                title="Habilidades y aptitudes de responsabilidad profesional"
              >
                Dim. 2
              </button>
              <button
                onClick={() => handleDimensionChange(3)}
                className={`flex-1 text-center py-1.5 rounded-lg text-xs font-medium transition-all ${
                  selectedDimension === 3
                    ? 'bg-white text-slate-800 shadow-sm font-bold'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
                title="Competencias socioemocionales"
              >
                Dim. 3
              </button>
            </div>
          </div>

          {/* Category Selector */}
          <div className="space-y-1">
            <label className="text-slate-500 text-xs font-semibold">Tema / Categoría</label>
            <div className="relative">
              <select
                value={selectedCategory}
                onChange={(e) => {
                  setSelectedCategory(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-50 text-slate-700 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all appearance-none cursor-pointer"
              >
                <option value="all">Cualquiera ({categoriesList.length} temas)</option>
                {categoriesList.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-slate-400">
                <Filter className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Search Input */}
          <div className="space-y-1 sm:col-span-2">
            <label className="text-slate-500 text-xs font-semibold">Buscar en texto</label>
            <div className="relative">
              <input
                type="text"
                placeholder="Escribe palabras clave o temas para filtrar..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-50 text-slate-700 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
              />
              <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-slate-400">
                <Search className="w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Questions Listing */}
      <div className="space-y-4">
        {paginatedQuestions.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center max-w-xl mx-auto">
            <AlertCircle className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h4 className="font-display font-bold text-slate-800 text-lg mb-1">
              No se encontraron preguntas
            </h4>
            <p className="text-slate-400 text-sm leading-relaxed">
              Prueba cambiando tus filtros de Dimensión o Categoría, o reduce la búsqueda de texto.
            </p>
            <button
              onClick={() => {
                setSelectedDimension('all');
                setSelectedCategory('all');
                setSearchQuery('');
                setShowFavoritesOnly(false);
                setCurrentPage(1);
              }}
              className="mt-5 px-4 py-2 bg-slate-100 hover:bg-slate-200/80 text-slate-700 text-xs font-semibold rounded-xl transition-all"
            >
              Restablecer Filtros
            </button>
          </div>
        ) : (
          paginatedQuestions.map((q) => {
            const isFav = stats[q.id]?.isFavorite || false;
            const isRevealed = revealedIds[q.id] || false;
            const noteValue = tempNotes[q.id] !== undefined ? tempNotes[q.id] : (stats[q.id]?.userNote || '');

            return (
              <div
                key={q.id}
                className={`bg-white rounded-2xl border transition-all ${
                  isFav ? 'border-amber-200 bg-amber-50/10' : 'border-slate-200/85 hover:border-slate-300'
                } shadow-sm overflow-hidden`}
              >
                {/* Upper info panel */}
                <div className="px-6 py-4 bg-slate-50/50 border-b border-slate-100 flex flex-wrap justify-between items-center gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-xs font-semibold text-slate-400 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-md">
                      Pregunta {q.id}
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                      q.dimension === 2 
                        ? 'bg-blue-50 text-blue-700 border border-blue-100' 
                        : 'bg-purple-50 text-purple-700 border border-purple-100'
                    }`}>
                      Dimensión {q.dimension}: {q.dimension === 2 ? 'Responsabilidad' : 'Socioemocionales'}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-200/70 text-slate-600">
                      {q.category}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Favorite Button */}
                    <button
                      onClick={() => onToggleFavorite(q.id)}
                      className={`p-1.5 rounded-lg border transition-all ${
                        isFav 
                          ? 'bg-amber-500/10 text-amber-500 border-amber-400' 
                          : 'text-slate-400 hover:text-amber-500 hover:bg-slate-100 border-slate-200'
                      }`}
                      title={isFav ? "Quitar de favoritos" : "Guardar como favorito"}
                    >
                      <Bookmark className="w-4 h-4 fill-current" />
                    </button>
                  </div>
                </div>

                {/* Case & Question Text */}
                <div className="p-6 md:p-8 space-y-4">
                  <h4 className="font-sans font-medium text-slate-800 text-sm md:text-base leading-relaxed">
                    {q.questionText}
                  </h4>

                  {/* Options List */}
                  <div className="space-y-2 mt-4">
                    {q.options.map((opt) => {
                      const isCorrect = opt.letter === q.correctLetter;
                      return (
                        <div
                          key={opt.letter}
                          className={`p-3.5 rounded-xl border text-xs md:text-sm flex items-start gap-3 transition-colors ${
                            isShowingAnswers(q.id) && isCorrect
                              ? 'bg-emerald-50 border-emerald-500/40 text-slate-800'
                              : 'bg-slate-50/50 border-slate-100 text-slate-600'
                          }`}
                        >
                          <span className={`w-6 h-6 shrink-0 rounded-full flex items-center justify-center font-mono font-bold text-xs ${
                            isShowingAnswers(q.id) && isCorrect
                              ? 'bg-emerald-500 text-white'
                              : 'bg-slate-200 text-slate-600'
                          }`}>
                            {opt.letter}
                          </span>
                          <span className="leading-relaxed mt-0.5">{opt.text}</span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Bottom reveal bar */}
                  <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <button
                      onClick={() => toggleReveal(q.id)}
                      className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                        isRevealed 
                          ? 'bg-slate-100 text-slate-700 hover:bg-slate-200' 
                          : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm'
                      }`}
                    >
                      <Eye className="w-4 h-4" />
                      <span>{isRevealed ? 'Ocultar Respuesta' : 'Revelar Respuesta'}</span>
                    </button>

                    {stats[q.id]?.userNote && (
                      <span className="text-[11px] text-indigo-600 font-semibold bg-indigo-50 px-2.5 py-1 rounded-lg">
                        ✓ Contiene anotaciones de estudio
                      </span>
                    )}
                  </div>

                  {/* Revealed Area */}
                  {isRevealed && (
                    <div className="mt-4 pt-5 border-t border-slate-100 space-y-4 animate-fade-in bg-slate-50/30 p-5 rounded-xl border border-dashed border-slate-200">
                      <div>
                        <div className="flex items-center gap-1.5 text-emerald-800 font-semibold text-xs mb-1.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                          <span>RESPUESTA CORRECTA: OPCIÓN {q.correctLetter}</span>
                        </div>
                        {q.justification && (
                          <div className="bg-emerald-50/50 border border-emerald-100 rounded-lg p-3 text-xs md:text-sm text-slate-700 leading-relaxed italic">
                            &quot;{q.justification}&quot;
                          </div>
                        )}
                      </div>

                      {/* Study Notes Block */}
                      <div className="space-y-2 pt-2">
                        <label className="block text-slate-700 font-semibold text-xs">
                          Mis Anotaciones de Estudio (Personalizado):
                        </label>
                        <div className="flex gap-2">
                          <textarea
                            rows={2}
                            placeholder="Escribe aquí un resumen o mnemotecnia para recordar este caso..."
                            value={noteValue}
                            onChange={(e) => setTempNotes(prev => ({ ...prev, [q.id]: e.target.value }))}
                            className="flex-1 min-h-[50px] p-2.5 text-xs text-slate-700 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                          />
                          <button
                            onClick={() => handleSaveNote(q.id)}
                            className="px-3 bg-slate-800 hover:bg-slate-900 text-white rounded-lg flex flex-col justify-center items-center text-[10px] gap-1 shrink-0"
                            title="Guardar anotación"
                          >
                            <Save className="w-4 h-4" />
                            <span>Guardar</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex justify-between items-center bg-white border border-slate-200 rounded-2xl px-6 py-4 shadow-sm" id="pagination-controls">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-semibold rounded-xl disabled:opacity-40 disabled:cursor-not-allowed transition-all"
          >
            Anterior
          </button>
          
          <span className="text-xs text-slate-500 font-sans">
            Pregunta <strong className="text-slate-800">{currentPage}</strong> de {totalPages} ({filteredQuestions.length} preguntas)
          </span>

          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-semibold rounded-xl disabled:opacity-40 disabled:cursor-not-allowed transition-all"
          >
            Siguiente
          </button>
        </div>
      )}
    </div>
  );

  // Helper functions
  function isFavorite(id: number): boolean {
    return stats[id]?.isFavorite || false;
  }

  function isShowingAnswers(id: number): boolean {
    return revealedIds[id] || false;
  }
}
