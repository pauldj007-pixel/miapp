import { Question } from '../types';

export const DIMENSION_3_PART_1: Question[] = [
  {
    id: 1,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "La alta carga administrativa a veces limita mi capacidad y energía para conectar emocionalmente con mis estudiantes como me gustaría.",
    options: [
      { letter: 'A', text: "Nunca, casi nunca" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Siempre, casi siempre" }
    ],
    correctLetter: 'C',
    justification: "Se busca balancear la carga de trabajo sin descuidar el vínculo emocional"
  },
  {
    id: 2,
    dimension: 3,
    category: "Autorregulación",
    questionText: "En épocas de fin de periodo o alta exigencia, tiendo a aceptar el agotamiento extremo como una parte normal e inevitable de nuestra profesión.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Rara vez" },
      { letter: 'C', text: "Frecuentemente" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Reconocimiento y aceptación de la realidad física del ritmo laboral"
  },
  {
    id: 3,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Si percibo que mi nivel de estrés crónico está afectando negativamente mi empatía con los alumnos o mi entorno familiar, acudo a redes de apoyo, colegas o profesionales de la salud mental de manera oportuna.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'C',
    justification: "Sinceridad del docente respecto a la dificultad para priorizar la salud"
  },
  {
    id: 4,
    dimension: 3,
    category: "Empatía",
    questionText: "Cuando un estudiante se muestra desafiante, logro separar mi ego profesional e identificar si su conducta es en realidad una manifestación de miedo, inseguridad o problemas familiares no expresados.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'B',
    justification: "Frecuentemente se logra des-escalar identificando la raíz"
  },
  {
    id: 5,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Tras un altercado o malentendido con un padre de familia o estudiante, me tomo un momento a solas para evaluar con honestidad mi propia responsabilidad en la escalada del conflicto.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'B',
    justification: "Evaluación honesta y reflexiva del rol en el conflicto"
  },
  {
    id: 6,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Reconozco de qué manera mis propias creencias familiares y culturales influyen en mis reacciones emocionales frente a comportamientos inesperados o distintos de mis estudiantes.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Se asume la necesidad de deconstruir sesgos para una labor imparcial"
  },
  {
    id: 7,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Intento desconectarme emocionalmente cuando los estudiantes me comparten problemas familiares para evitar que eso me afecte y nuble mi objetividad.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Establecer límites profesionales para preservar la salud emocional"
  },
  {
    id: 8,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Cuando siento que las autoridades de la institución toman decisiones poco justas o arbitrarias, prefiero desahogar mi frustración conversando con mis colegas de confianza en los pasillos en lugar de expresar mi desacuerdo formalmente en juntas.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "El perfil óptimo requiere asertividad y canales institucionales"
  },
  {
    id: 9,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Cuando un estudiante cuestiona o debate mis explicaciones de forma muy insistente, le indico que acate las instrucciones por el momento para no retrasar el avance de la clase con el resto del grupo.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Se promueve el debate, el pensamiento crítico y la escucha activa"
  },
  {
    id: 10,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Cuando comunico los resultados de una evaluación a los representantes legales, me aseguro de iniciar destacando las fortalezas y progresos del estudiante antes de abordar constructivamente las áreas que necesitan refuerzo académico.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Estrategia asertiva de comunicación positiva y alianza constructiva con familias"
  },
  {
    id: 11,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Incluso en los días donde el comportamiento del grupo es altamente disruptivo, logro procesar mi frustración internamente sin descargar mi carga de estrés sobre los estudiantes.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Autocontrol y responsabilidad afectiva en la conducción de aula"
  },
  {
    id: 12,
    dimension: 3,
    category: "Empatía",
    questionText: "Cuando un representante muestra negación, frustración o enojo al recibir un diagnóstico de necesidades educativas específicas de su hijo, aplico la empatía para comprender su proceso de duelo antes de exigirle resultados.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Comprensión empática del duelo familiar ante barreras de aprendizaje"
  },
  {
    id: 13,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Suelo posponer mi propio descanso o atención médica leve porque siento que cumplir con la planificación y la entrega de notas es más urgente.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Refleja el alto nivel de exigencia y compromiso, aunque requiere balance"
  },
  {
    id: 14,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Dedico tiempo regularmente a la introspección para evaluar si mis reacciones diarias en el colegio son coherentes con los principios éticos de justicia y de respeto que exijo a mis propios alumnos.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "La autoevaluación constante es base del crecimiento profesional ético"
  },
  {
    id: 15,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Cuando dos estudiantes presentan versiones contradicciones sobre un incidente, facilito un espacio de diálogo donde ambos puedan exponer sus emociones y llegar a un acuerdo mutuo, actuando yo como mediador.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Resolución pacífica de conflictos con enfoque restaurativo y mediador"
  },
  {
    id: 16,
    dimension: 3,
    category: "Empatía",
    questionText: "A veces me resulta difícil incorporar o validar las costumbres de estudiantes de otras nacionalidades o culturas sin alterar el ritmo general y la planificación que ya tengo establecida.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "La inclusión y valoración intercultural no se condicionan por rigidez curricular"
  },
  {
    id: 17,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Mantengo una comunicación constante con los representantes legales, no solo para informar sobre faltas disciplinarias o bajo rendimiento, sino también para reconocer y celebrar proactivamente los progresos de sus hijos.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Fomento de una alianza positiva celebrando logros estudiantiles con el hogar"
  },
  {
    id: 18,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Frecuentemente mis colegas o mis propios alumnos me hacen notar que estoy utilizando un tono de voz agresivo, sarcástico o impaciente, sin que yo misma me haya dado cuenta.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "El autoconocimiento asertivo previene micro-agresiones o tonos lesivos"
  },
  {
    id: 19,
    dimension: 3,
    category: "Empatía",
    questionText: "Por costumbre o rapidez, al organizar dinámicas y eventos en el aula, suelo asignar tareas de decoración o cuidado a las alumnas y de fuerza física a los alumnos.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Prevención de estereotipos tradicionales de género para co-educación equitativa"
  },
  {
    id: 20,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Me resulta incómodo admitir frente al grupo que he cometido un error, pues me preocupa que afecte la percepción de mi preparación o autoridad.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "La aceptación del error modela la honestidad intelectual y la resiliencia"
  },
  {
    id: 21,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Cuando tengo un desacuerdo metodológico o pedagógico con un colega durante una junta, ¿logro expresar mi punto de vista con firmeza, pero sin invalidar su experiencia o conocimientos?",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Comunicación asertiva entre pares sin menoscabo del saber mutuo"
  },
  {
    id: 22,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Utilizo estrategias efectivas de gestión de tiempo para planificar mis clases y tareas pedagógicas, lo que me permite disminuir significativamente los factores estresantes del entorno escolar.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Asume que el trabajo docente se rige bajo una microplanificación constante"
  },
  {
    id: 23,
    dimension: 3,
    category: "Empatía",
    questionText: "Adapto mis expectativas y estrategias pedagógicas reconociendo que no todos mis estudiantes parten desde las mismas condiciones socioeconómicas o familiares, aplicando el principio de equidad.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Principio medular del DUA, equidad y la educación inclusiva"
  },
  {
    id: 24,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Dedico mi tiempo de rutina semanal, exclusivamente a actividades recreativas de ocio o deportivas que me permiten oxigenar la mente y desconectar totalmente del entorno escolar.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Sinceridad ante la dificultad real del docente de aislar su tiempo libre por completo"
  },
  {
    id: 25,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Cuando pierdo la paciencia durante la jornada laboral, tiendo a atribuirlo casi exclusivamente a la falta de interés o actitud de mis estudiantes.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "La gestión de la paciencia y las emociones es responsabilidad del educador"
  },
  {
    id: 26,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Con frecuencia me encuentro pensando en evaluaciones pendientes, matrices del ministerio o situaciones del aula durante mi tiempo de descanso en casa.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Muestra la imposibilidad común de desconexión absoluta (Realidad ocupacional)"
  },
  {
    id: 27,
    dimension: 3,
    category: "Empatía",
    questionText: "Fomento en mis estudiantes una conciencia ambiental, guiándolos para que comprendan cómo sus acciones cotidianas impactan en la naturaleza y en el derecho a un entorno sostenible.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Inserción transversal obligatoria de educación ambiental"
  },
  {
    id: 28,
    dimension: 3,
    category: "Empatía",
    questionText: "En ocasiones la premura por cumplir con los requerimientos del sistema hace que mi trato diario con los estudiantes deba ser más directivo y menos cálido.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "La calidez y empatía socioemocional no se negocian por presión externa"
  },
  {
    id: 29,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Evalúo constantemente si mis decisiones y mi carga de trabajo actual están afectando mi bienestar físico y mental, realizando ajustes oportunos para proteger mi proyecto de vida.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'C',
    justification: "Honestidad del docente que pocas veces prioriza su salud por sobre la carga"
  },
  {
    id: 30,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Considero que la observación de clases entre colegas, aunque bien intencionada, suele invadir la privacidad pedagógica y puede generar comparaciones innecesarias entre docentes.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Defensa de la observación cooperativa y coevaluación para la mejora"
  },
  {
    id: 31,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Siento que intervenir frecuentemente en las pequeñas burlas o roces diarios entre los alumnos les resta autonomía, por lo que prefiero dejar que lo resuelvan entre ellos para que forjen su carácter frente a la adversidad.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Tolerar las 'pequeñas burlas' normaliza el acoso; la intervención es obligatoria"
  },
  {
    id: 32,
    dimension: 3,
    category: "Empatía",
    questionText: "Autoevalúo y modifico conscientemente mis comentarios, bromas o ejemplos en clase para asegurar que no estoy perpetuando roles de género machistas, estereotipos culturales o prejuicios sociales.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Responsabilidad social de modelaje e inclusión no discriminatoria"
  },
  {
    id: 33,
    dimension: 3,
    category: "Empatía",
    questionText: "Para garantizar que soy completamente justo e imparcial, aplico exactamente las mismas reglas y consecuencias para todos mis estudiantes sin excepción, incluso si conozco que alguno atraviesa problemas familiares complejos.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Garantía normada de equidad y orden objetivo dentro del aula"
  },
  {
    id: 34,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Al intervenir en un conflicto entre estudiantes, priorizo que reconozcan el impacto emocional de sus acciones en el otro (enfoque restaurativo) antes de aplicar cualquier medida disciplinaria contemplada en el código de convivencia.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Alineado a las nuevas metodologías y lineamientos del DECE"
  },
  {
    id: 35,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Cuando un estudiante presenta un problema recurrente de comportamiento, convoco una reunión con el DECE y la familia para diseñar un plan de apoyo conjunto, asumiendo mi cuota de corresponsabilidad en el proceso.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Trabajo en conjunto bajo la trilogía educativa (Familia-Escuela-Comunidad)"
  },
  {
    id: 36,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Suelo acumular y silenciar mis pequeñas molestias diarias con los estudiantes o autoridades hasta llegar a un punto de saturación donde finalmente reacciono de manera desproporcionada o explosiva.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Un perfil óptimo descarta explosiones emocionales en la institución"
  },
  {
    id: 37,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Ante situaciones de alta presión o sobrecarga administrativa, aplico conscientemente técnicas de relajación y autocuidado para evitar que el estrés afecte mi desempeño en el aula.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Uso elemental de pausas activas sugeridas por el DECE y salud ocupacional"
  },
  {
    id: 38,
    dimension: 3,
    category: "Empatía",
    questionText: "Promuevo en el aula la reflexión crítica sobre problemas globales y locales como el cambio climático o la desigualdad, motivando a los estudiantes a proponer acciones sostenibles desde su realidad.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Construcción activa del pensamiento crítico y ciudadanía global"
  },
  {
    id: 39,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Dado el volumen de contenidos del currículo por cubrir, a veces me resulta difícil encontrar el espacio para atender las inquietudes emocionales individuales del grupo.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'C',
    justification: "Reconoce que aunque el tiempo limita, el rol individualizado es necesario"
  },
  {
    id: 40,
    dimension: 3,
    category: "Autorregulación",
    questionText: "A veces el ritmo de las actividades escolares me impide tomar pausas adecuadas, por lo que suelo terminar la jornada con tensión muscular o fatiga física.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'B',
    justification: "Aceptación real del impacto físico intrínseco de la labor docente"
  },
  {
    id: 41,
    dimension: 3,
    category: "Empatía",
    questionText: "Con tantos alumnos en el aula, a veces me resulta poco realista y casi imposible aplicar de forma estricta las adaptaciones curriculares individualizadas para cada estudiante con necesidades específicas.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Las adaptaciones con base en NEE y DUA son de aplicación obligatoria"
  },
  {
    id: 42,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Procuro mantener una distancia estrictamente académica con mis estudiantes, pues involucrarme demasiado en sus contextos personales me resulta emocionalmente desgastante.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "El docente establece límites profesionales claros, sin ser terapeuta"
  },
  {
    id: 43,
    dimension: 3,
    category: "Empatía",
    questionText: "A veces creo que los estudiantes aislados o tímidos deberían esforzarse más por integrarse al grupo en lugar de esperar que el resto siempre dé el primer paso.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Se deben respetar ritmos y estilos de personalidad; inclusión proactiva"
  },
  {
    id: 44,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Frecuentemente priorizo el cumplimiento de los objetivos académicos de mi materia, dejando en un segundo plano la contención de las preocupaciones afectivas o problemas sociales de mis alumnos.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'C',
    justification: "Equilibrio formativo para no descuidar el clima áulico"
  },
  {
    id: 45,
    dimension: 3,
    category: "Empatía",
    questionText: "Mantengo una actitud de observación constante y activa para identificar cambios sutiles en el comportamiento de mis alumnos que puedan indicar situaciones de acoso, bullying o violencia en su entorno.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Vigilancia activa obligatoria frente a rutas y protocolos de violencia"
  },
  {
    id: 46,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Con frecuencia confundo el cansancio físico severo con enojo, terminando por reprender a mis estudiantes cuando en realidad lo que necesito es un descanso mental.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Garantiza que el alumnado no reciba proyecciones de estrés laboral"
  },
  {
    id: 47,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Logro mantener un equilibrio emocional y una postura objetiva al enfrentar situaciones imprevistas o de emergencia escolar, evitando entrar en un estado de pánico que afecte al grupo.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Liderazgo y contención docente en momentos críticos o simulacros"
  },
  {
    id: 48,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Ante un clima de aula constantemente tenso, suelo pensar que la razón principal es que las nuevas generaciones son mucho más difíciles de manejar.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "No se debe culpabilizar a la generación, sino evaluar las dinámicas áulicas"
  },
  {
    id: 49,
    dimension: 3,
    category: "Empatía",
    questionText: "En ocasiones dejo pasar bromas pesadas entre los estudiantes sobre su origen o situación económica, ya que intervenir en cada comentario menor me quitaría demasiado tiempo en clase.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Cero tolerancia institucional a la discriminación de cualquier tipo"
  },
  {
    id: 50,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Paso por alto el impacto emocional que me generan las constantes presiones administrativas o los reclamos de los padres, asumiendo que, si los ignoro, eventualmente desaparecerán por sí solos.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Los factores psicosociales y estrés no se ignoran; se gestionan a tiempo"
  },
  {
    id: 51,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "En los proyectos interdisciplinarios con otros docentes suelo asumir la mayor parte de la planificación yo mismo, ya que esperar a consensuar los aportes de todos retrasa el cumplimiento del cronograma institucional.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'C',
    justification: "Refleja el intento de trabajar de forma colaborativa, tolerando desajustes de ritmos"
  },
  {
    id: 52,
    dimension: 3,
    category: "Empatía",
    questionText: "Por practicidad suelo asignar tareas completamente distintas y separadas a los estudiantes con necesidades educativas especiales para que el resto del grupo pueda avanzar en el currículo.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "La exclusión encubierta está prohibida; se fomenta la co-participación inclusiva"
  },
  {
    id: 53,
    dimension: 3,
    category: "Empatía",
    questionText: "En ocasiones siento que los adolescentes magnifican sus problemas sociales entre compañeros, por lo que trato de restarles importancia y cambiar de tema para que aprendan a enfocarse en sus estudios.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "La validación constante de los sentimientos es base de la confianza"
  },
  {
    id: 54,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Logro adaptarme con flexibilidad y resiliencia cuando ocurren cambios imprevistos en el cronograma o en las directrices escolares, evitando que la frustración inicial paralice mi labor.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Adaptabilidad imprescindible ante directrices cambiantes"
  },
  {
    id: 55,
    dimension: 3,
    category: "Empatía",
    questionText: "Aprovecho las situaciones cotidianas o noticias de la comunidad para generar debates en la clase sobre la justicia social, los derechos humanos y la equidad, desarrollando el pensamiento ético del grupo.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Formación ciudadana activa y transversalización ética"
  }
];
