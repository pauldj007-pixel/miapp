import { Question } from '../types';

export const DIMENSION_2_QUESTIONS: Question[] = [
  {
    id: 1,
    dimension: 2,
    category: "Gestión de Recursos",
    questionText: "¿Cómo gestiona el uso responsable de los recursos físicos y tecnológicos?",
    options: [
      { letter: 'A', text: "No tomo medidas específicas para promover el uso responsable de los recursos educativos" },
      { letter: 'B', text: "Implementa normas de uso responsable con el estudiantado y da seguimiento a su cumplimiento" },
      { letter: 'C', text: "Recuerdo a los estudiantes que cuiden los recursos cuando observo mal uso, sin estrategia planificada." },
      { letter: 'D', text: "Diseña sistemas de gestión responsable, involucra al estudiantado en el cuidado activo y propone mejoras institucionales para optimizar el uso de los recursos disponibles." }
    ],
    correctLetter: 'D',
    justification: "Práctica docente de nivel excelente/destacado según rúbrica"
  },
  {
    id: 2,
    dimension: 2,
    category: "Evaluación Formativa",
    questionText: "¿De qué manera usa la evaluación formativa para ajustar su práctica pedagógica?",
    options: [
      { letter: 'A', text: "Diseña y aplica sistemas de evaluación formativa diversificados, los usa para ajustar la enseñanza de manera inmediata y comparte sus estrategias con colegas." },
      { letter: 'B', text: "No utilizo estrategias de evaluación formativa durante el proceso de enseñanza." },
      { letter: 'C', text: "Aplica instrumentos de evaluación formativa planificados y ajusta sus estrategias en función de los resultados." },
      { letter: 'D', text: "Hago preguntas orales para verificar comprensión general, sin estrategias sistemáticas." }
    ],
    correctLetter: 'A',
    justification: "Uso inmediato, diversificado y colaborativo de la evaluación"
  },
  {
    id: 3,
    dimension: 2,
    category: "Involucramiento Comunitario",
    questionText: "¿De qué manera involucra a la comunidad en proyectos de impacto ambiental o social?",
    options: [
      { letter: 'A', text: "No desarrollo proyectos de impacto ambiental o social con la comunidad educativa." },
      { letter: 'B', text: "Co-diseña y co-ejecuta proyectos de alto impacto, evalúa sus resultados, sistematiza las lecciones aprendidas y promueve su continuidad institucional." },
      { letter: 'C', text: "Propongo ideas de proyectos comunitarios, pero sin llevarlos a la práctica." },
      { letter: 'D', text: "Diseña y ejecuta proyectos de impacto ambiental o social con participación del estudiantado y la comunidad." }
    ],
    correctLetter: 'B',
    justification: "Enfoque participativo, sistemático y de impacto duradero"
  },
  {
    id: 4,
    dimension: 2,
    category: "Formación Continua",
    questionText: "¿Cómo utiliza los recursos digitales aprendidos en la formación continua?",
    options: [
      { letter: 'A', text: "Incorpora regularmente los recursos digitales aprendidos en sus procesos de enseñanza y evaluación." },
      { letter: 'B', text: "Usa, adapta y diversifica los recursos digitales, los comparte con colegas, forma a otros en su uso y promueve la innovación tecnológica institucional." },
      { letter: 'C', text: "Utilizo ocasionalmente alguna herramienta digital, pero sin planificación ni seguimiento de su impacto." },
      { letter: 'D', text: "No utilizo los recursos digitales o plataformas aprendidos en los espacios de formación." }
    ],
    correctLetter: 'B',
    justification: "Adaptación, transferencia de conocimiento e innovación institucional"
  },
  {
    id: 5,
    dimension: 2,
    category: "Trabajo Colaborativo",
    questionText: "¿De qué manera promueve una cultura de colaboración y mejora continua entre colegas?",
    options: [
      { letter: 'A', text: "No promuevo activamente una cultura de colaboración o mejora continua." },
      { letter: 'B', text: "Lidera la construcción de una cultura de colaboración y mejora, diseña espacios de aprendizaje colectivo, evalúa su impacto y los integra como práctica institucional sostenida." },
      { letter: 'C', text: "Participo en actividades colaborativas cuando me convocan, sin proponer ni impulsar iniciativas propias." },
      { letter: 'D', text: "Propone e impulsa iniciativas de colaboración, comparte recursos y estimula el trabajo en equipo." }
    ],
    correctLetter: 'B',
    justification: "Liderazgo en la creación de espacios de aprendizaje institucional sostenidos"
  },
  {
    id: 6,
    dimension: 2,
    category: "Selección de Recursos",
    questionText: "¿De qué manera selecciona los recursos más pertinentes para cada proceso de enseñanza?",
    options: [
      { letter: 'A', text: "Selecciona los recursos con criterios pedagógicos de pertinencia, accesibilidad y adecuación al contexto del grupo." },
      { letter: 'B', text: "Diseña criterios fundamentados, evalúa el impacto de los recursos en el aprendizaje y contribuye a la construcción de bancos de recursos institucionales." },
      { letter: 'C', text: "Uso los mismos recursos de siempre sin evaluar si son los más pertinentes." },
      { letter: 'D', text: "Selecciono recursos según su facilidad de acceso, sin criterios pedagógicos claros." }
    ],
    correctLetter: 'B',
    justification: "Diseño de criterios, evaluación de impacto y aporte a bancos compartidos"
  },
  {
    id: 7,
    dimension: 2,
    category: "Trabajo Colaborativo",
    questionText: "¿Cómo documenta los aprendizajes obtenidos en las comunidades profesionales?",
    options: [
      { letter: 'A', text: "Sistematiza los aprendizajes, los integra al plan de formación institucional y promueve la construcción de memoria pedagógica colectiva." },
      { letter: 'B', text: "No documento los aprendizajes obtenidos en las comunidades o redes profesionales." },
      { letter: 'C', text: "Tomo notas personales en algunas reuniones, pero sin sistematizar ni compartir lo aprendido." },
      { letter: 'D', text: "Documento de manera regular los aprendizajes y los comparte con el equipo institucional." }
    ],
    correctLetter: 'A',
    justification: "Sistematización para la memoria pedagógica y la formación colectiva"
  },
  {
    id: 8,
    dimension: 2,
    category: "Trabajo Colaborativo",
    questionText: "¿De qué manera colabora con colegas para resolver desafíos pedagógicos comunes?",
    options: [
      { letter: 'A', text: "No busco la colaboración de colegas para resolver los desafíos pedagógicos de mi práctica." },
      { letter: 'B', text: "Consulto a colegas ocasionalmente cuando un problema pedagógico me parece irresoluble de manera individual." },
      { letter: 'C', text: "Facilita procesos colaborativos de resolución de problemas, sistematiza las soluciones encontradas y promueve su adopción institucional." },
      { letter: 'D', text: "Propongo y participo regularmente en espacios de colaboración para resolver desafíos pedagógicos compartidos." }
    ],
    correctLetter: 'C',
    justification: "Facilitador de resolución colaborativa y sistematización institucional"
  },
  {
    id: 9,
    dimension: 2,
    category: "Normativa y PEI",
    questionText: "¿De qué manera contribuye a la construcción o actualización del PEI?",
    options: [
      { letter: 'A', text: "Contribuye activamente con aportes pedagógicos fundamentados y da seguimiento a la implementación del PEI." },
      { letter: 'B', text: "No participo en la construcción ni actualización del PEI de mi institución." },
      { letter: 'C', text: "Lidera equipos de construcción del PEI, articula los aportes docentes, evalúa la coherencia con la práctica pedagógica y promueve su apropiación colectiva." },
      { letter: 'D', text: "Participo en actividades de actualización del PEI cuando me convocan, sin aportes propios." }
    ],
    correctLetter: 'C',
    justification: "Liderazgo, articulación docente y fomento de la apropiación colectiva"
  },
  {
    id: 10,
    dimension: 2,
    category: "Clima de Aula",
    questionText: "¿De qué manera promueve un clima emocional seguro y positivo en su aula?",
    options: [
      { letter: 'A', text: "Implementa estrategias planificadas para promover el bienestar emocional y el clima positivo del aula de manera regular." },
      { letter: 'B', text: "Intervengo ante situaciones de conflicto cuando son evidentes, pero sin un plan preventivo." },
      { letter: 'C', text: "No implemento estrategias planificadas para promover un clima emocional seguro en el aula." },
      { letter: 'D', text: "Diseña, implementa y evalúa estrategias de bienestar emocional, las comparte con colegas y coordina con el DECE para fortalecer el acompañamiento integral." }
    ],
    correctLetter: 'D',
    justification: "Coordinación con el DECE y transferencia de estrategias con colegas"
  },
  {
    id: 11,
    dimension: 2,
    category: "Clima de Aula",
    questionText: "¿Cómo promueve un clima emocional seguro y positivo en su aula? (Repetida en PDF para consistencia)",
    options: [
      { letter: 'A', text: "Implementa estrategias planificadas para promover el bienestar emocional y el clima positivo del aula de manera regular." },
      { letter: 'B', text: "Intervengo ante situaciones de conflicto cuando son evidentes, pero sin un plan preventivo." },
      { letter: 'C', text: "No implemento estrategias planificadas para promover un clima emocional seguro en el aula." },
      { letter: 'D', text: "Diseña, implementa y evalúa estrategias de bienestar emocional, las comparte con colegas y coordina con el DECE para fortalecer el acompañamiento integral." }
    ],
    correctLetter: 'D',
    justification: "Diseño, evaluación y articulación trans-disciplinaria"
  },
  {
    id: 12,
    dimension: 2,
    category: "Trabajo Colaborativo",
    questionText: "¿Cómo participa en los espacios colaborativos de reflexión pedagógica institucional?",
    options: [
      { letter: 'A', text: "Participo activamente, comparto estrategias de mi práctica y recibo e incorporo los aportes de los colegas." },
      { letter: 'B', text: "No participo en los espacios colaborativos de reflexión pedagógica o lo hago de manera pasiva." },
      { letter: 'C', text: "Asisto a los espacios colaborativos cuando me lo piden, pero sin preparar aportes ni compartir experiencias." },
      { letter: 'D', text: "Lidero o facilito espacios colaborativos, comparte evidencias sistematizadas, promueve la reflexión crítica colectiva y contribuye al aprendizaje institucional de manera sostenida." }
    ],
    correctLetter: 'D',
    justification: "Liderazgo o facilitación, evidencias sistematizadas y reflexión crítica"
  },
  {
    id: 13,
    dimension: 2,
    category: "Formación Continua",
    questionText: "¿Cómo actualiza su conocimiento disciplinar y pedagógico de manera autónoma?",
    options: [
      { letter: 'A', text: "Ejecuto un plan sistemático de actualización, comparto los aprendizajes con colegas, produzco reflexiones propias y contribuyo al conocimiento colectivo del equipo." },
      { letter: 'B', text: "Leo materiales ocasionalmente, pero sin un plan sistemático de actualización." },
      { letter: 'C', text: "No realizo actualización autónoma fuera de las capacitaciones obligatorias." },
      { letter: 'D', text: "Tengo un plan de actualización autónoma, leo regularmente sobre mi área y aplico los aprendizajes en mi práctica." }
    ],
    correctLetter: 'A',
    justification: "Plan sistemático que genera conocimiento colectivo compartido"
  },
  {
    id: 14,
    dimension: 2,
    category: "Planificación Curricular",
    questionText: "¿De qué manera incorpora el enfoque de DUA en sus planificaciones?",
    options: [
      { letter: 'A', text: "Conozco el DUA, pero solo hago ajustes puntuales para estudiantes con NEE diagnosticadas." },
      { letter: 'B', text: "No incorporo los principios del DUA en mis planificaciones curriculares." },
      { letter: 'C', text: "Diseña planificaciones con DUA sistemático, evalúa su impacto en la diversidad del aula y promueve el DUA como enfoque institucional." },
      { letter: 'D', text: "Diseña planificaciones aplicando los tres principios del DUA de manera regular." }
    ],
    correctLetter: 'C',
    justification: "Enfoque sistemático del DUA de carácter institucional"
  },
  {
    id: 15,
    dimension: 2,
    category: "Planificación Curricular",
    questionText: "¿Cómo alinea su práctica pedagógica con el perfil de salida del estudiantado?",
    options: [
      { letter: 'A', text: "Diseño mis actividades pedagógicas teniendo en cuenta los atributos del perfil de salida de manera habitual." },
      { letter: 'B', text: "Conozco el perfil de salida, pero lo consulto solo cuando debo llenar formatos oficiales." },
      { letter: 'C', text: "Articulo todas mis planificaciones con el perfil de salida, socializo esta articulación con colegas y promueve que el equipo trabaje colectivamente hacia el mismo perfil." },
      { letter: 'D', text: "No utilizo el perfil de salida como referente para diseñar mis clases o actividades." }
    ],
    correctLetter: 'C',
    justification: "Articulación total, socialización colectiva e impulso grupal"
  },
  {
    id: 16,
    dimension: 2,
    category: "Evaluación Formativa",
    questionText: "¿De qué manera implementa retroalimentación pedagógica en el acompañamiento estudiantil?",
    options: [
      { letter: 'A', text: "Ofrezco retroalimentación general cuando me la solicitan o ante situaciones problemáticas evidentes." },
      { letter: 'B', text: "No incorporo estrategias de retroalimentación pedagógica en los procesos de acompañamiento." },
      { letter: 'C', text: "Diseño estrategias de retroalimentación planificadas, con orientaciones específicas para cada estudiante." },
      { letter: 'D', text: "Implementa retroalimentación diferenciada y sistemática, coordina con el DECE y con las familias, y da seguimiento al impacto de las acciones de acompañamiento." }
    ],
    correctLetter: 'D',
    justification: "Retroalimentación diferenciada con seguimiento e involucramiento de DECE y familias"
  },
  {
    id: 17,
    dimension: 2,
    category: "Evaluación Formativa",
    questionText: "¿Cómo adapta los instrumentos de evaluación para responder a la diversidad del aula?",
    options: [
      { letter: 'A', text: "Uso los mismos instrumentos para todos los estudiantes, sin adaptaciones." },
      { letter: 'B', text: "Diseña instrumentos de evaluación diversificados que responden a las diferencias de aprendizaje del grupo." },
      { letter: 'C', text: "Diseña, implementa y evalúa instrumentos adaptativos desde los principios del DUA, los comparte con colegas y promueve la evaluación inclusiva como práctica institucional." },
      { letter: 'D', text: "Hago ajustes mínimos para estudiantes con NEE formalmente identificadas cuando me lo solicitan." }
    ],
    correctLetter: 'C',
    justification: "Creación bajo el marco DUA, fomento institucional y de alcance compartido"
  },
  {
    id: 18,
    dimension: 2,
    category: "Planificación Curricular",
    questionText: "¿Cómo ajusta su planificación a partir de los resultados de cada unidad?",
    options: [
      { letter: 'A', text: "Reflexiona sobre los resultados de cada unidad, identifica qué funcionó y planifica las mejoras para la siguiente." },
      { letter: 'B', text: "No realizo ajustes a mi planificación a partir de los resultados de las unidades desarrolladas." },
      { letter: 'C', text: "Sistematiza la reflexión sobre las unidades, documenta las mejoras, comparte los aprendizajes con el equipo y contribuye a la memoria pedagógica institucional." },
      { letter: 'D', text: "Hago ajustes espontáneos cuando algo no funciona, sin analizar sistemáticamente los resultados." }
    ],
    correctLetter: 'C',
    justification: "Sistematización y contribución activa a la memoria pedagógica"
  },
  {
    id: 19,
    dimension: 2,
    category: "Trabajo Colaborativo",
    questionText: "¿Cómo asume un rol de liderazgo pedagógico en su institución?",
    options: [
      { letter: 'A', text: "Acepto roles de liderazgo cuando me los asignan, sin iniciativa propia ni compromisos adicionales." },
      { letter: 'B', text: "Asume roles de liderazgo pedagógico con iniciativa, impulsa proyectos de mejora y acompaña a colegas." },
      { letter: 'C', text: "No asumo roles de liderazgo pedagógico más allá de las funciones formalmente asignadas." },
      { letter: 'D', text: "Ejerce liderazgo pedagógico distribuido, inspira a otros, articula el trabajo colectivo hacia metas compartidas y construye capacidad institucional para la mejora continua." }
    ],
    correctLetter: 'D',
    justification: "Liderazgo distribuido que genera capacidad institucional compartida"
  },
  {
    id: 20,
    dimension: 2,
    category: "Trabajo Colaborativo",
    questionText: "¿Cómo contribuye al acompañamiento de docentes en proceso de inducción?",
    options: [
      { letter: 'A', text: "Oriento a los docentes nuevos solo cuando me lo solicitan o cuando el directivo me lo asigna." },
      { letter: 'B', text: "Acompaño proactivamente a los docentes en inducción, comparto recursos y ofrezco retroalimentación constructiva." },
      { letter: 'C', text: "Lidera el proceso de inducción, diseña itinerarios de acompañamiento, sistematiza las lecciones aprendidas e integra las conclusiones al plan de formación institucional." },
      { letter: 'D', text: "No participo en la formación ni en el acompañamiento de docentes nuevos en la institución." }
    ],
    correctLetter: 'C',
    justification: "Liderazgo, estructuración de itinerarios y fomento del aprendizaje colectivo"
  },
  {
    id: 21,
    dimension: 2,
    category: "Formación Continua",
    questionText: "¿De qué manera selecciona los espacios de formación más pertinentes para su desarrollo?",
    options: [
      { letter: 'A', text: "Selecciono los espacios de formación con base en un diagnóstico de mis necesidades y los objetivos de mi área." },
      { letter: 'B', text: "Elijo algunas capacitaciones según mi disponibilidad, pero sin criterios claros de pertinencia." },
      { letter: 'C', text: "Diseño un plan de formación personalizado con criterios técnicos, evalúo la pertinencia y comparto los criterios con colegas para fortalecer la selección colectiva." },
      { letter: 'D', text: "No selecciono los espacios de formación con criterios propios; asisto solo a los que me asignan." }
    ],
    correctLetter: 'C',
    justification: "Plan personalizado, fomento de criterios técnicos y toma colectiva de decisiones"
  },
  {
    id: 22,
    dimension: 2,
    category: "Formación Continua",
    questionText: "¿Cómo incorpora los aprendizajes de las capacitaciones en su práctica de aula?",
    options: [
      { letter: 'A', text: "Planifico, ejecuto y documento la transferencia de aprendizajes, comparto los resultados con colegas y promuevo que los espacios de formación sean fuente de mejora colectiva." },
      { letter: 'B', text: "Intento aplicar algunos aprendizajes de las capacitaciones, pero de manera aislada y sin articulación." },
      { letter: 'C', text: "Planifico la transferencia de los aprendizajes a mi práctica de aula y evalúo su impacto." },
      { letter: 'D', text: "No aplico en el aula los aprendizajes obtenidos en las capacitaciones a las que asisto." }
    ],
    correctLetter: 'A',
    justification: "Transferencia documentada, compartida y promotora de la mejora colectiva"
  },
  {
    id: 23,
    dimension: 2,
    category: "Clima de Aula",
    questionText: "¿De qué manera registra y da seguimiento al progreso individual del estudiantado?",
    options: [
      { letter: 'A', text: "Registro las calificaciones en los formatos institucionales, sin análisis de tendencias individuales." },
      { letter: 'B', text: "Implementa sistemas de seguimiento individualizados, los comparte con el DECE y las familias, y co-diseña planes de acción diferenciados." },
      { letter: 'C', text: "Mantiene registros sistemáticos del progreso por estudiante e identifica tendencias para diseñar intervenciones." },
      { letter: 'D', text: "No llevo registros sistemáticos del progreso individual más allá de las notas requeridas." }
    ],
    correctLetter: 'B',
    justification: "Seguimiento individual, articulación institucional (DECE) y familiar"
  },
  {
    id: 24,
    dimension: 2,
    category: "Formación Continua",
    questionText: "¿De qué manera reflexiona sobre los aspectos de su práctica que requieren mejora?",
    options: [
      { letter: 'A', text: "Realizo reflexiones periódicas, identifico áreas de mejora y diseño acciones concretas para aplicarlas." },
      { letter: 'B', text: "Reflexiono sobre mi práctica cuando algo sale mal, pero sin sistematizar el proceso ni documentar conclusiones." },
      { letter: 'C', text: "No dedico tiempo específico a reflexionar sobre los aspectos de mi práctica que necesitan mejorar." },
      { letter: 'D', text: "Reflexiono de manera sistemática, documento las conclusiones, las comparto con pares y lidero procesos de mejora colectiva en el equipo." }
    ],
    correctLetter: 'D',
    justification: "Reflexión sistemática, compartida y de carácter colaborativo-liderazgo"
  },
  {
    id: 25,
    dimension: 2,
    category: "Desarrollo Sostenible",
    questionText: "¿Cómo promueve prácticas sostenibles en el aula y en la institución?",
    options: [
      { letter: 'A', text: "No promuevo prácticas sostenibles en el aula ni en la institución de manera planificada." },
      { letter: 'B', text: "Menciono la importancia de las prácticas sostenibles sin implementar acciones concretas." },
      { letter: 'C', text: "Implementa prácticas sostenibles en el aula, las conecta con el aprendizaje curricular." },
      { letter: 'D', text: "Promueve prácticas sostenibles en el aula y la institución, lidera iniciativas con el estudiantado y la comunidad, y comparte las experiencias como buenas prácticas institucionales." }
    ],
    correctLetter: 'D',
    justification: "Prácticas de amplio alcance con involucramiento comunitario e institucional"
  },
  {
    id: 26,
    dimension: 2,
    category: "Patrimonio Educativo",
    questionText: "¿Cómo promueve la valoración y cuidado del patrimonio educativo institucional?",
    options: [
      { letter: 'A', text: "Diseña proyectos pedagógicos donde el estudiantado es protagonista del cuidado y mejora del patrimonio educativo, y promueve esta cultura más allá del aula." },
      { letter: 'B', text: "Incorpora estrategias pedagógicas planificadas para desarrollar una actitud de valoración y cuidado del patrimonio." },
      { letter: 'C', text: "No incorpora acciones específicas para que los estudiantes valoren y cuiden el patrimonio educativo." },
      { letter: 'D', text: "Hablo sobre el cuidado de los recursos cuando ocurre algún daño, sin estrategias preventivas." }
    ],
    correctLetter: 'A',
    justification: "Proyectos en que los estudiantes son protagonistas activos de cambio social"
  },
  {
    id: 27,
    dimension: 2,
    category: "Gestión de Riesgos",
    questionText: "¿Cómo aplica los procedimientos del Plan de Gestión de Riesgos?",
    options: [
      { letter: 'A', text: "Conoce y aplica los procedimientos del Plan de Gestión de Riesgos oportunamente e informa a las autoridades ante situaciones de riesgo." },
      { letter: 'B', text: "Conoce, aplica y difunde los procedimientos, participa en la actualización del plan y promueve una cultura institucional de prevención y seguridad." },
      { letter: 'C', text: "Conozco los procedimientos generales, pero los aplico principalmente durante los simulacros obligatorios." },
      { letter: 'D', text: "No conozco con precisión los procedimientos del Plan de Gestión de Riesgos de mi institución." }
    ],
    correctLetter: 'B',
    justification: "Difusión de procedimientos, participación en actualización y cultura preventiva"
  },
  {
    id: 28,
    dimension: 2,
    category: "Gestión de Riesgos",
    questionText: "¿De qué manera contribuye a la cultura de prevención y seguridad institucional?",
    options: [
      { letter: 'A', text: "Contribuye activamente a la cultura de prevención, comparte información y participa en las iniciativas institucionales." },
      { letter: 'B', text: "No participo activamente en la construcción de una cultura de prevención y seguridad." },
      { letter: 'C', text: "Cumplo con los requerimientos mínimos de seguridad cuando me los solicitan." },
      { letter: 'D', text: "Lidera iniciativas de cultura preventiva, facilita la formación de la comunidad educativa en seguridad y articula las estrategias con el PEI." }
    ],
    correctLetter: 'D',
    justification: "Liderazgo de iniciativas, facilitación formativa y vinculación al PEI"
  },
  {
    id: 29,
    dimension: 2,
    category: "Formación Continua",
    questionText: "¿Cómo evidencia el impacto de la formación recibida en los resultados del estudiantado?",
    options: [
      { letter: 'A', text: "Diseña indicadores para evaluar el impacto de la formación en el aprendizaje del estudiantado y los monitorea regularmente." },
      { letter: 'B', text: "Evalúa el impacto de manera sistemática, documenta los resultados, los comparte con el equipo y ajusta las estrategias de formación en función de la evidencia." },
      { letter: 'C', text: "Observo cambios generales después de una capacitación, pero sin medir ni documentar su impacto." },
      { letter: 'D', text: "No hago seguimiento al impacto de las capacitaciones en los resultados de mis estudiantes." }
    ],
    correctLetter: 'B',
    justification: "Evaluación sistemática orientada a la evidencia y su retroalimentación en estrategias"
  },
  {
    id: 30,
    dimension: 2,
    category: "Planificación Curricular",
    questionText: "¿De qué manera comparte con sus estudiantes los propósitos de aprendizaje de cada clase?",
    options: [
      { letter: 'A', text: "Menciono los propósitos al inicio de la clase, pero sin conectarlos con el perfil de salida ni con los objetivos institucionales." },
      { letter: 'B', text: "No comunico los propósitos de aprendizaje; inicio la clase directamente con las actividades." },
      { letter: 'C', text: "Co-construyo los propósitos con los estudiantes, los vínculos con el PEI y el perfil de salida, y promuevo que el estudiantado asuma un rol activo en la definición de sus metas de aprendizaje." },
      { letter: 'D', text: "Comunico y explico los propósitos de aprendizaje, los vínculos con el perfil de salida y verifico su comprensión." }
    ],
    correctLetter: 'C',
    justification: "Co-construcción y rol activo en metas de aprendizaje vinculadas al PEI"
  },
  {
    id: 31,
    dimension: 2,
    category: "Planificación Curricular",
    questionText: "¿Cómo integra metodologías activas en su planificación curricular?",
    options: [
      { letter: 'A', text: "Incluyo alguna actividad participativa, pero sin planificarla explícitamente como metodología activa." },
      { letter: 'B', text: "Diseña secuencias basadas en metodologías activas, evalúa su impacto, comparte las experiencias con colegas y promueve la innovación metodológica institucional." },
      { letter: 'C', text: "Planifica y aplica metodologías activas de manera regular y coherente con los objetivos curriculares." },
      { letter: 'D', text: "No incorporo metodologías activas en mis planificaciones; predomina la clase magistral." }
    ],
    correctLetter: 'B',
    justification: "Integración, evaluación, fomento colectivo e innovación de metodologías"
  },
  {
    id: 32,
    dimension: 2,
    category: "Desarrollo Sostenible",
    questionText: "¿Cómo incorpora los principios de la EDS (Educación para el Desarrollo Sostenible) en su planificación curricular?",
    options: [
      { letter: 'A', text: "No incorporo los principios de la EDS en mi planificación ni en mis clases." },
      { letter: 'B', text: "Incluyo referencias a la sostenibilidad de manera esporádica cuando el contenido lo sugiere." },
      { letter: 'C', text: "Articula sistemáticamente la EDS con el currículo, diseña proyectos interdisciplinarios con impacto real y promueve la EDS como eje transversal institucional." },
      { letter: 'D', text: "Integra los principios de la EDS de manera planificada, conectando los contenidos con problemas reales de sostenibilidad." }
    ],
    correctLetter: 'C',
    justification: "Articulación sistemática, interdisciplinaridad y alcance transversal institucional"
  },
  {
    id: 33,
    dimension: 2,
    category: "Bienestar Estudiantil",
    questionText: "¿De qué manera articula acciones con el DECE para el seguimiento del bienestar estudiantil?",
    options: [
      { letter: 'A', text: "Me relaciono con el DECE solo cuando hay situaciones críticas que requieren intervención especializada." },
      { letter: 'B', text: "No coordino acciones con el DECE para el seguimiento del bienestar de mis estudiantes." },
      { letter: 'C', text: "Trabaja articulada y proactivamente con el DECE, co-diseña estrategias de acompañamiento, participa en los planes de intervención y evalúa colectivamente los resultados." },
      { letter: 'D', text: "Coordina regularmente con el DECE, comparte observaciones e implementa sus recomendaciones pedagógicas." }
    ],
    correctLetter: 'C',
    justification: "Trabajo co-diseñado, proactivo y con evaluación colectiva del bienestar"
  },
  {
    id: 34,
    dimension: 2,
    category: "Evaluación Formativa",
    questionText: "¿Cómo involucra a los estudiantes en la evaluación de su propio aprendizaje?",
    options: [
      { letter: 'A', text: "No incorporo estrategias de autoevaluación ni coevaluación en mis procesos de evaluación." },
      { letter: 'B', text: "Implementa procesos de autoevaluación y coevaluación de manera regular, con instrumentos que guían la reflexión." },
      { letter: 'C', text: "Diseña sistemas de evaluación participativos donde el estudiante co-construye los criterios y usa los resultados para dirigir su propio aprendizaje." },
      { letter: 'D', text: "Aplico autoevaluación ocasionalmente, principalmente al final de las unidades, sin orientar el proceso." }
    ],
    correctLetter: 'C',
    justification: "Sistemas de co-construcción participativa que fomentan la autorregulación"
  },
  {
    id: 35,
    dimension: 2,
    category: "Formación Continua",
    questionText: "¿De qué manera aplica metodologías innovadoras aprendidas en espacios de formación formal?",
    options: [
      { letter: 'A', text: "Aplica regularmente metodologías innovadoras, las adapta a su contexto y evalúa su efectividad." },
      { letter: 'B', text: "No aplico metodologías innovadoras en mi práctica, aunque las haya conocido en capacitaciones." },
      { letter: 'C', text: "He intentado aplicar alguna metodología nueva de manera esporádica y sin evaluación." },
      { letter: 'D', text: "Aplica, adapta, sistematiza y comparte metodologías innovadoras con sus colegas, promoviendo su adopción institucional y el análisis colectivo de resultados." }
    ],
    correctLetter: 'D',
    justification: "Adaptación, transferencia sistemática y promoción de la adopción colectiva"
  },
  {
    id: 36,
    dimension: 2,
    category: "Formación Continua",
    questionText: "¿Cómo gestiona su participación en procesos de formación docente organizados institucionalmente?",
    options: [
      { letter: 'A', text: "Participo activamente en los procesos de formación, reflexiono sobre los aprendizajes y los aplico en mi práctica." },
      { letter: 'B', text: "No participo en los procesos de formación más allá de los estrictamente obligatorios." },
      { letter: 'C', text: "Asisto a las capacitaciones requeridas, pero sin reflexionar sobre cómo aplicar los aprendizajes." },
      { letter: 'D', text: "Participo activamente, aplico y sistematizo los aprendizajes, los comparto con colegas y promuevo la formación como práctica de mejora colectiva institucional." }
    ],
    correctLetter: 'D',
    justification: "Fomento de la formación docente como palanca de cambio institucional colectivo"
  },
  {
    id: 37,
    dimension: 2,
    category: "Involucramiento Comunitario",
    questionText: "¿Cómo comparte los logros de su gestión pedagógica con la comunidad educativa?",
    options: [
      { letter: 'A', text: "No comparto con la comunidad los logros ni los aprendizajes de mi gestión pedagógica." },
      { letter: 'B', text: "Comunica regularmente los logros y aprendizajes de su gestión con estudiantes, familias y colegas." },
      { letter: 'C', text: "Comparto resultados puntuales cuando me lo solicitan, sin sistematización ni reflexión colectiva." },
      { letter: 'D', text: "Diseña estrategias de comunicación sistemáticas, involucra a la comunidad en la reflexión colectiva y usa los aprendizajes compartidos para alimentar los planes de mejora institucional." }
    ],
    correctLetter: 'D',
    justification: "Comunicación sistemática y bidireccional dirigida a alimentar la mejora continua"
  },
  {
    id: 38,
    dimension: 2,
    category: "Gestión de Recursos",
    questionText: "¿De qué manera contribuye a la gestión eficiente de recursos en su institución?",
    options: [
      { letter: 'A', text: "Participa activamente en la gestión eficiente, hace propuestas de optimización y colabora en el mantenimiento preventivo." },
      { letter: 'B', text: "No participo en la gestión de recursos más allá del uso directo en mis clases." },
      { letter: 'C', text: "Lidera iniciativas de gestión eficiente, propone mejoras basadas en diagnóstico, coordina con autoridades y comparte las estrategias con la comunidad educativa." },
      { letter: 'D', text: "Reporto cuando un recurso está dañado, pero sin propuestas de mejora o gestión preventiva." }
    ],
    correctLetter: 'C',
    justification: "Iniciativas de liderazgo con diagnóstico, coordinación institucional y socialización"
  },
  {
    id: 39,
    dimension: 2,
    category: "Educación Socioemocional",
    questionText: "¿Cómo incorpora estrategias de educación socioemocional en su práctica pedagógica?",
    options: [
      { letter: 'A', text: "Incluyo ocasionalmente reflexiones socioemocionales cuando el contexto lo exige, sin planificación." },
      { letter: 'B', text: "Planifica e implementa regularmente estrategias de educación socioemocional integradas a los contenidos curriculares." },
      { letter: 'C', text: "No incorporo estrategias de educación socioemocional en mi práctica." },
      { letter: 'D', text: "Diseña, implementa y evalúa estrategias de educación socioemocional, las articula transversalmente con el currículo, comparte su práctica con colegas y promueve su institucionalización." }
    ],
    correctLetter: 'D',
    justification: "Socioemocional transversal, evaluado, colaborativo y con enfoque institucional"
  },
  {
    id: 40,
    dimension: 2,
    category: "Planificación Curricular",
    questionText: "¿De qué manera articula su planificación con los resultados de la evaluación diagnóstica?",
    options: [
      { letter: 'A', text: "Diseña planificaciones altamente personalizadas a partir del diagnóstico y monitorea el impacto de los ajustes en el progreso de los estudiantes." },
      { letter: 'B', text: "No utilizo los resultados de la evaluación diagnóstica para ajustar mi planificación." },
      { letter: 'C', text: "Analiza los resultados diagnósticos, identifica necesidades del grupo y ajusta con estrategias diferenciadas." },
      { letter: 'D', text: "Reviso los resultados diagnósticos, pero hago ajustes mínimos sin diferenciación sistemática." }
    ],
    correctLetter: 'A',
    justification: "Planificaciones altamente personalizadas y con monitoreo riguroso"
  },
  {
    id: 41,
    dimension: 2,
    category: "Bienestar Estudiantil",
    questionText: "¿Cómo identifica y activa las rutas de protección ante indicios de vulnerabilidad estudiantil?",
    options: [
      { letter: 'A', text: "Conozco los protocolos, pero los activo solo cuando la situación de riesgo es muy evidente." },
      { letter: 'B', text: "Identifico indicios tempranos, los registro y activo la ruta de protección de manera oportuna, informando al DECE y a las autoridades." },
      { letter: 'C', text: "Identifico, registro y activa protocolos oportunamente, da seguimiento al proceso de intervención y promueve entre colegas el conocimiento de las señales tempranas." },
      { letter: 'D', text: "No conozco con precisión las rutas de protección ni los protocolos de actuación." }
    ],
    correctLetter: 'C',
    justification: "Detección, activación, seguimiento exhaustivo y capacitación de pares frente a vulneraciones"
  },
  {
    id: 42,
    dimension: 2,
    category: "Trabajo Colaborativo",
    questionText: "¿De qué manera comparte buenas prácticas pedagógicas con sus colegas?",
    options: [
      { letter: 'A', text: "Comparto informalmente alguna estrategia o recurso cuando un colega me lo pide directamente." },
      { letter: 'B', text: "No comparto mis prácticas pedagógicas con colegas de manera sistemática." },
      { letter: 'C', text: "Sistematizo y difundo mis buenas prácticas, facilito su adopción por parte de colegas y promuevo la construcción colectiva de conocimiento pedagógico institucional." },
      { letter: 'D', text: "Comparto regularmente estrategias, recursos y resultados de mi práctica en espacios formales e informales." }
    ],
    correctLetter: 'C',
    justification: "Sistematización rigurosa, difusión y fomento de un repositorio de saberes institucionales"
  },
  {
    id: 43,
    dimension: 2,
    category: "Gestión de Riesgos",
    questionText: "¿De qué manera prepara a sus estudiantes para actuar ante emergencias?",
    options: [
      { letter: 'A', text: "Refuerza periódicamente el conocimiento de los procedimientos con el estudiantado y explica roles y rutas." },
      { letter: 'B', text: "Trabaja sistemáticamente la preparación para emergencias, involucra a los estudiantes en la mejora del plan y articula esta formación con el currículo." },
      { letter: 'C', text: "No preparo a mi estudiantes para emergencias más allá de los simulacros institucionales." },
      { letter: 'D', text: "Informo a los estudiantes sobre los procedimientos solo durante los simulacros programados." }
    ],
    correctLetter: 'B',
    justification: "Involucramiento activo estudiantil, mejora del plan y contextualización curricular"
  },
  {
    id: 44,
    dimension: 2,
    category: "Evaluación Formativa",
    questionText: "¿Cómo utiliza los resultados de evaluación del estudiantado para mejorar su práctica pedagógica?",
    options: [
      { letter: 'A', text: "Analizo sistemáticamente los resultados por indicador, ajusto mi práctica con base en evidencia, documento los cambios y comparto los aprendizajes con mis colegas." },
      { letter: 'B', text: "Reviso los resultados al final del quimestre, pero sin implementar cambios sistemáticos." },
      { letter: 'C', text: "Analizo los resultados de manera periódica, identifico brechas y ajusto mis estrategias de enseñanza en consecuencia." },
      { letter: 'D', text: "No analizo los resultados de evaluación para ajustar mi práctica docente." }
    ],
    correctLetter: 'A',
    justification: "Análisis sistemático de base empírica por indicador y socialización con pares"
  },
  {
    id: 45,
    dimension: 2,
    category: "Involucramiento Comunitario",
    questionText: "¿Cómo comunica los resultados de aprendizaje a estudiantes y representantes?",
    options: [
      { letter: 'A', text: "Comunico las calificaciones y señalo de manera general qué aspectos mejorar, sin personalizar." },
      { letter: 'B', text: "Implementa retroalimentación diferenciada, involucra al estudiantado en autoevaluación y mantiene comunicación regular con las familias sobre el desarrollo académico y socioemocional." },
      { letter: 'C', text: "Comunica resultados con retroalimentación específica, usa lenguaje positivo y dialoga con representantes sobre el progreso integral." },
      { letter: 'D', text: "Entrego las calificaciones sin explicar qué aspectos debe mejorar ni cómo hacerlo." }
    ],
    correctLetter: 'B',
    justification: "Retroalimentación adaptativa y bidireccional continua con la familia"
  },
  {
    id: 46,
    dimension: 2,
    category: "Trabajo Colaborativo",
    questionText: "¿Cómo colabora con colegas para articular los contenidos de su área con otras áreas?",
    options: [
      { letter: 'A', text: "Coordino con otros docentes solo cuando el equipo directivo lo requiere explícitamente." },
      { letter: 'B', text: "Lidero procesos de articulación curricular interdisciplinaria, promuevo proyectos integrados y analizo con el equipo el impacto en el aprendizaje del estudiantado." },
      { letter: 'C', text: "No realizo articulación curricular con otras áreas; trabajo de manera aislada en mi planificación." },
      { letter: 'D', text: "Propongo y ejecuto actividades de articulación curricular con colegas de otras áreas de manera regular." }
    ],
    correctLetter: 'B',
    justification: "Liderazgo en articulación curricular interdisciplinaria y evaluación de impacto conjunta"
  },
  {
    id: 47,
    dimension: 2,
    category: "Normativa y PEI",
    questionText: "¿Cómo integra los objetivos del PEI en su planificación curricular?",
    options: [
      { letter: 'A', text: "Integro los objetivos del PEI en mi planificación, los comparto con colegas, promuevo la articulación curricular entre áreas y verifico colectivamente su impacto." },
      { letter: 'B', text: "Conozco los objetivos del PEI, pero los incorporo en mi planificación solo cuando me lo solicitan." },
      { letter: 'C', text: "Integro regularmente los objetivos del PEI en mi planificación microcurricular, asegurando coherencia con la misión institucional." },
      { letter: 'D', text: "No conozco o no considero los objetivos del PEI al momento de planificar mis clases." }
    ],
    correctLetter: 'A',
    justification: "Integración, fomento colaborativo e inter-áreas, y evaluación colectiva"
  },
  {
    id: 48,
    dimension: 2,
    category: "Desarrollo Sostenible",
    questionText: "¿De qué manera desarrolla el pensamiento crítico frente a problemas socioambientales?",
    options: [
      { letter: 'A', text: "No desarrollo actividades específicas para el pensamiento crítico frente a problemas socioambientales." },
      { letter: 'B', text: "Diseña actividades que desarrollan el pensamiento crítico frente a problemas socioambientales reales del entorno." },
      { letter: 'C', text: "Planteo preguntas generales sobre el medio ambiente cuando el tema aparece en el currículo." },
      { letter: 'D', text: "Facilita procesos de investigación y acción sobre problemas socioambientales reales, promueve el pensamiento sistémico y el liderazgo ciudadano del estudiantado." }
    ],
    correctLetter: 'D',
    justification: "Sistematización de procesos activos de investigación, acción y liderazgo estudiantil"
  },
  {
    id: 49,
    dimension: 2,
    category: "Trabajo Colaborativo",
    questionText: "¿Cuál es su nivel de participación en los procesos de mejora institucional?",
    options: [
      { letter: 'A', text: "Participa activamente en los procesos de mejora, aporta ideas fundamentadas y reflexiona sobre el impacto." },
      { letter: 'B', text: "Evito participar en los procesos de mejora o planificación institucional." },
      { letter: 'C', text: "Lidera o co-lidera procesos de mejora, articula propuestas con el PEI, promueve la participación colectiva y monitorea los resultados." },
      { letter: 'D', text: "Participo cuando me lo solicitan, pero sin aportes propios ni reflexión sobre mi contribución." }
    ],
    correctLetter: 'C',
    justification: "Liderazgo, alineación al PEI, co-creación colectiva y evaluación de indicadores"
  },
  {
    id: 50,
    dimension: 2,
    category: "Convivencia Escolar",
    questionText: "¿Cómo previene y aborda situaciones de acoso escolar entre pares?",
    options: [
      { letter: 'A', text: "No tengo estrategias específicas para prevenir o abordar el acoso escolar." },
      { letter: 'B', text: "Implementa estrategias preventivas e identifica situaciones de acoso, activando los protocolos institucionales de manera oportuna." },
      { letter: 'C', text: "Intervengo cuando observo situaciones de acoso, pero sin activar los protocolos institucionales." },
      { letter: 'D', text: "Implementa estrategias preventivas sistemáticas, activa protocolos oportunamente, realiza seguimiento a los casos y promueve una cultura institucional de prevención de la violencia." }
    ],
    correctLetter: 'D',
    justification: "Sistematicidad, rigor en activación de protocolos, seguimiento y fomento cultural preventivo"
  },
  {
    id: 51,
    dimension: 2,
    category: "Gestión de Riesgos",
    questionText: "¿Cómo identifica y reporta condiciones de riesgo en el entorno escolar?",
    options: [
      { letter: 'A', text: "Realiza inspecciones periódicas, reporta con documentación detallada, propone medidas correctivas y da seguimiento a su implementación." },
      { letter: 'B', text: "No identifico ni reporto condiciones de riesgo de manera sistemática." },
      { letter: 'C', text: "Identifica y reporta proactivamente las condiciones de riesgo siguiendo los canales institucionales establecidos." },
      { letter: 'D', text: "Reporto condiciones de riesgo solo cuando son muy evidentes o afectan directamente a mis estudiantes." }
    ],
    correctLetter: 'A',
    justification: "Enfoque de auditoría activo, documentado, con propuesta de soluciones y control de ejecución"
  },
  {
    id: 52,
    dimension: 2,
    category: "Desarrollo Sostenible",
    questionText: "¿Cómo conecta los contenidos de su área con los Objetivos de Desarrollo Sostenible (ODS)?",
    options: [
      { letter: 'A', text: "Planifica conexiones explícitas entre los contenidos curriculares y los ODS, generando aprendizajes contextualizados." },
      { letter: 'B', text: "Menciono algunos ODS cuando aparecen relacionados naturalmente con el contenido." },
      { letter: 'C', text: "Articula sistemáticamente los ODS con el currículo, diseña proyectos transversales orientados a los ODS y promueve su incorporación como eje pedagógico institucional." },
      { letter: 'D', text: "No establezco conexiones entre los contenidos de mi área y los ODS." }
    ],
    correctLetter: 'C',
    justification: "Plan transversal integral e institucionalización del marco sostenible ODS"
  },
  {
    id: 53,
    dimension: 2,
    category: "Convivencia Escolar",
    questionText: "¿De qué manera incorpora los valores del Código de Convivencia en su práctica pedagógica?",
    options: [
      { letter: 'A', text: "No incorporo activamente los valores del Código de Convivencia en mi práctica pedagógica." },
      { letter: 'B', text: "Promuevo activamente los valores del Código de Convivencia, los articulo con el currículo y facilito que el estudiantado los interiorice y aplique en su vida cotidiana." },
      { letter: 'C', text: "Incorporo regularmente los valores del Código de Convivencia en mi práctica y en la gestión del clima de aula." },
      { letter: 'D', text: "Menciono el Código de Convivencia solo cuando hay situaciones de conflicto." }
    ],
    correctLetter: 'B',
    justification: "Internalización y aplicación activa para la ciudadanía en la vida diaria"
  }
];
