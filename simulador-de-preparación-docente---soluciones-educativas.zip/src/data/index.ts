import { Question } from '../types';
import { DIMENSION_2_QUESTIONS } from './dimension2';
import { DIMENSION_3_PART_1 } from './dimension3_part1';
import { DIMENSION_3_PART_2 } from './dimension3_part2';

export const QUESTIONS: Question[] = [
  ...DIMENSION_2_QUESTIONS,
  ...DIMENSION_3_PART_1,
  ...DIMENSION_3_PART_2
];

// Helper to get questions of a specific dimension
export function getQuestionsByDimension(dimension: 2 | 3): Question[] {
  return QUESTIONS.filter(q => q.dimension === dimension);
}

// Helper to get all categories for a given dimension
export function getCategoriesByDimension(dimension: 2 | 3): string[] {
  const categories = QUESTIONS.filter(q => q.dimension === dimension).map(q => q.category);
  return Array.from(new Set(categories));
}
