import { Question } from '../types';

export const DIMENSION_3_PART_2: Question[] = [
  {
    id: 56,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Suelo evitar mostrar que estoy cansado o estresado frente a los estudiantes, ya que siento que podría restar formalidad a mi rol docente.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Preservación de la compostura formal frente al alumnado"
  },
  {
    id: 57,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Planifico mis actividades pedagógicas utilizando estrategias de gestión de tiempo, lo que me permite reducir significativamente la ansiedad y los factores estresantes del entorno laboral.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'B',
    justification: "Reconoce que aunque se intente, variables externas alteran el tiempo planeado"
  },
  {
    id: 58,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Soy capaz de identificar emociones complejas en mí mismo como la frustración, la impotencia o el miedo al fracaso antes de que estas se conviertan en conductas impulsivas dentro del aula.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Inteligencia emocional y conciencia introspectiva aplicadas"
  },
  {
    id: 59,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Me mantengo atento a las dinámicas sociales del aula, interviniendo de manera formativa si noto que un estudiante está siendo sutilmente ignorado o aislado por sus compañeros en los trabajos grupales.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Fomento activo de la cohesión del grupo e inclusión preventiva"
  },
  {
    id: 60,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Frente a un problema de indisciplina reiterada, procuro generar un espacio de diálogo privado con el estudiante para entender el motivo real de su actitud, en lugar de limitarme únicamente a emitir un reporte escrito.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Enfoque formativo y restaurativo sobre el punitivo tradicional"
  },
  {
    id: 61,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Promuevo que los estudiantes propongan iniciativas o proyectos para solucionar problemas del entorno escolar, validando su capacidad de liderazgo y rol como ciudadanos activos dentro de la comunidad educativa.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Metodologías activas basadas en proyectos (ABP) y empoderamiento estudiantil"
  },
  {
    id: 62,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Tengo claramente identificados cuáles son mis detonantes emocionales específicos (por ejemplo, el ruido excesivo, las interrupciones o la apatía) que me hacen perder mi centro pedagógico.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'B',
    justification: "Autoconocimiento asertivo para la autorregulación constante"
  },
  {
    id: 63,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Ante la ansiedad de un estudiante frente a un examen, le animo a que aprenda a manejar la presión por su cuenta, ya que el sistema educativo y la vida laboral exigen rendir bajo altos niveles de estrés.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "El docente debe brindar contención y no desentenderse de la salud mental"
  },
  {
    id: 64,
    dimension: 3,
    category: "Empatía",
    questionText: "A veces siento que los estudiantes en situación de movilidad humana (migrantes) requieren un nivel de atención o nivelación que sobrepasa mis posibilidades dentro de un aula regular.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'C',
    justification: "Admite la complejidad técnica de nivelar sin rechazar la inclusión"
  },
  {
    id: 65,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Considero los errores pedagógicos o el fracaso de una clase planificada como oportunidades valiosas para reflexionar y ajustar mi didáctica en lugar de motivos para castigarme emocionalmente.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Resiliencia pedagógica y mentalidad de crecimiento continuo"
  },
  {
    id: 66,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Noto que en los días con mayor presión académica mi tolerancia a las interrupciones normales o inquietudes del aula disminuye considerablemente.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'B',
    justification: "Aceptación sincera de la vulnerabilidad humana legítima del educador"
  },
  {
    id: 67,
    dimension: 3,
    category: "Empatía",
    questionText: "Si detecto dinámicas de exclusión hacia un estudiante por sus características culturales o personales, diseño actividades de aprendizaje cooperativas que requieran la interdependencia positiva del grupo para resolver la situación de forma natural.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Uso estratégico e instrumental de la pedagogía inclusiva activa"
  },
  {
    id: 68,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Cuando experimento una carga emocional abrumadora debido a las demandas del entorno escolar, busco proactivamente el apoyo de profesionales o colegas de confianza en lugar de aislarme.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'B',
    justification: "Búsqueda asertiva de descompresión emocional y redes de apoyo"
  },
  {
    id: 69,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Si un representante se comunica conmigo en un tono alterado por una calificación o un incidente, mantengo un volumen de voz sereno y escucho toda su queja antes de presentar mis argumentos técnicos.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Técnica de desactivación asertiva frente a conflictos verbales"
  },
  {
    id: 70,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Me resulta incómodo cuando un estudiante cuestiona o pide demasiadas explicaciones sobre la forma en que he evaluado su trabajo frente a los demás e intento cerrar el tema rápidamente para no perder el orden y la autoridad en clase.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "La evaluación debe ser transparente, justa y explicada pacientemente"
  },
  {
    id: 71,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Soy capaz de reconocer y verbalizar ante mis estudiantes cuando mi estado de ánimo no es el mejor, modelando con mi ejemplo que todas las emociones humanas son válidas y manejables.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Validación emocional asertiva y modelado regulatorio frente al aula"
  },
  {
    id: 72,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Después de experimentar un conflicto o un momento de alta tensión en el aula, dedico tiempo en privado a analizar qué emociones sentí y por qué reaccioné de esa manera.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Práctica reflexiva indispensable posterior a la clase"
  },
  {
    id: 73,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Frente a un cambio inesperado en la normativa del ministerio o en la planificación institucional, logro mantener la calma y reorganizar mis estrategias pedagógicas sin que la frustración me paralice.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Garantiza la operatividad, adaptabilidad y tranquilidad áulica"
  },
  {
    id: 74,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Reflexiono de manera consciente sobre cómo mis propias creencias, valores y prejuicios personales influyen en la forma en que juzgo y califico el comportamiento de mis estudiantes.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Se aspira a la total imparcialidad profesional en procesos evaluativos"
  },
  {
    id: 75,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Fomento que mis estudiantes participen activamente en la creación y revisión de las normas de convivencia del aula para que comprendan el sentido de las reglas y asuman corresponsabilidad.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Construcción democrática, dialógica y consensuada de la convivencia"
  },
  {
    id: 76,
    dimension: 3,
    category: "Empatía",
    questionText: "Incorporo intencionalmente en mi planificación saberes, tradiciones y aportes de diferentes culturas (indígenas, afroecuatorianas, montubias) para enriquecer el aprendizaje y fomentar el respeto a la plurinacionalidad.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Cumplimiento obligatorio de los mandatos interculturales curriculares"
  },
  {
    id: 77,
    dimension: 3,
    category: "Empatía",
    questionText: "Dedico tiempo a escuchar activamente y validar las opiniones de mis estudiantes, incluso cuando sus perspectivas culturales o sociales difieren radicalmente de mis propias creencias.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Fomento activo de la libertad de expresión, pensamiento y diversidad"
  },
  {
    id: 78,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Aunque reconozco el valor del trabajo en equipo docente, generalmente prefiero planificar y ejecutar mis proyectos escolares de forma individual porque resulta mucho más rápido y evita discusiones innecesarias con colegas.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'B',
    justification: "Acepta con sinceridad la complejidad práctica de consensuar dinámicas"
  },
  {
    id: 79,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "A veces me resulta difícil distinguir si mi frustración en el aula se debe al comportamiento del grupo o a las preocupaciones personales que traigo desde casa.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "El docente maduro delimita con rigor el ámbito escolar de lo privado"
  },
  {
    id: 80,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Considero que experimentar cierto nivel de estrés constante y ansiedad es simplemente el precio que los docentes debemos pagar por nuestro compromiso con la educación.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "No se debe normalizar ni romantizar el desgaste psicopedagógico"
  },
  {
    id: 81,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Cuando hay una falta disciplinaria, prefiero aplicar la sanción del reglamento de inmediato en lugar de invertir tiempo en largos procesos de diálogo restaurativo que no siempre funcionan.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Garantía de aplicación de la norma objetiva reguladora institucional"
  },
  {
    id: 82,
    dimension: 3,
    category: "Empatía",
    questionText: "Cuando los representantes faltan continuamente a las reuniones, tiendo a interpretar que delegan toda la responsabilidad en el colegio sin tener tiempo para investigar sus motivos de fondo.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Se debe conceder el beneficio de la duda y buscar los factores reales"
  },
  {
    id: 83,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Logro establecer límites claros entre mi horario de trabajo y mi vida personal, evitando revisar tareas o contestar mensajes de representantes fuera de mi jornada laboral para proteger mi descanso.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Describe con honestidad la hiperconexión común por canales móviles (WhatsApp)"
  },
  {
    id: 84,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Cuando percibo mucha tensión o enojo por parte de un padre de familia durante la tutoría, prefiero darle la razón rápidamente o acortar la reunión para evitar que el ambiente se vuelva más conflictivo.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Estrategia prudencial defensiva de des-escalamiento ante hostilidad manifiesta"
  },
  {
    id: 85,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Al finalizar un día agotador, tiendo a recordar más los incidentes de indisciplina que los pequeños momentos de conexión positiva con el grupo.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "El perfil asertivo enfoca sus esfuerzos y reflexiones en los logros del día"
  },
  {
    id: 86,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Cuando la mayoría de los estudiantes reprueba una evaluación, considero que mi responsabilidad es avanzar con el cronograma oficial para no perjudicar el cumplimiento del currículo anual.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Si reprueba el 50% o más, la retroalimentación y nivelación es prioritaria"
  },
  {
    id: 87,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Identifico rápidamente cambios en mi propio cuerpo, como respiración agitada, tensión en el cuello o dolor de cabeza, como una señal de alerta temprana antes de perder la paciencia.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'B',
    justification: "Conciencia psicosomática del estrés y manejo oportuno de impulsos"
  },
  {
    id: 88,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Frente a un daño o falta grave en la convivencia, priorizo el diálogo restaurativo que permite al infractor comprender el dolor emocional causado al otro en lugar de limitarme a aplicar un castigo punitivo.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Alineación rigurosa con el marco de prácticas restaurativas de convivencia"
  },
  {
    id: 89,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Soy consciente de que mi estado de ánimo personal al ingresar al colegio determina la atmósfera emocional de mis estudiantes, por lo que procuro gestionar mi actitud antes de iniciar clase.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Responsabilidad y coherencia afectiva del educador como líder de aula"
  },
  {
    id: 90,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Intervengo de manera proactiva si noto que un estudiante está siendo sutilmente excluido de los grupos de trabajo, facilitando dinámicas de integración sin exponerlo públicamente ante el curso.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Cuidado de la dignidad individual, equidad e inclusión respetuosa"
  },
  {
    id: 91,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Me doy cuenta de que en ocasiones tengo menos paciencia con aquellos estudiantes cuya actitud o personalidad choca con mi forma de ser.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "El autocontrol asertivo previene favoritismos o sesgos reactivos"
  },
  {
    id: 92,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Tengo claridad sobre cuáles son mis principales debilidades emocionales y didácticas, lo que me permite pedir ayuda al DECE o buscar capacitación sin sentir que mi orgullo se ve amenazado.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Humildad profesional y apertura al aprendizaje permanente"
  },
  {
    id: 93,
    dimension: 3,
    category: "Empatía",
    questionText: "Identifico y cuestiono de manera constructiva los estereotipos de género y prejuicios culturales que surgen en los textos escolares o en las conversaciones del aula, promoviendo la equidad.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Rol de facilitador como agente activo de equidad y justicia social"
  },
  {
    id: 94,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Dado lo extenso del currículo y el poco tiempo de clase, cuando surge un roce o malentendido menor entre estudiantes, suelo enviarlos directamente al DECE o a inspección en lugar de detener mi planificación para mediar el problema.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "La mediación en el aula fomenta habilidades para la vida y es deber docente"
  },
  {
    id: 95,
    dimension: 3,
    category: "Empatía",
    questionText: "Conecto deliberadamente los contenidos de mi asignatura con problemáticas del mundo real como el cambio climático, la pobreza o la desigualdad para fomentar una conciencia ciudadana global crítica.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Vinculación contextual reflexiva y pedagogía con impacto real"
  },
  {
    id: 96,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Analizo habitualmente si mi estado de ánimo está alineado con mis propósitos pedagógicos, asegurándome de no transmitir mi propio pesimismo o apatía al grupo de los alumnos.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Preservación activa del clima motivacional e intencionalidad afectiva"
  },
  {
    id: 97,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Fomento que en los trabajos grupales los estudiantes asuman diferentes roles rotativos, promoviendo que todos, independientemente de su nivel académico, tengan una participación activa y valorada.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Estructura democrática activa mediante aprendizaje cooperativo equitativo"
  },
  {
    id: 98,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Solicito activamente retroalimentación a mis colegas sobre cómo perciben mi comunicación y lenguaje corporal en situaciones de estrés, aceptando sus observaciones sin reaccionar a la defensiva.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'C',
    justification: "Describe de manera sincera la baja periodicidad de esta interconsulta profesional"
  },
  {
    id: 99,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Al corregir el comportamiento de un estudiante frente al grupo, me enfoco en señalar la acción específica que debe mejorar, cuidando de mantener un tono de voz sereno que no afecte su dignidad ni lo exponga a la burla.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Respeto estricto e irrenunciable de los derechos y la dignidad infantil"
  },
  {
    id: 100,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "A veces me preocupa que mostrar demasiada comprensión ante las situaciones personales de los alumnos pueda terminar relajando la disciplina del aula.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "La empatía constructiva no cancela el orden ni el rigor normativo"
  },
  {
    id: 101,
    dimension: 3,
    category: "Manejo de Emociones",
    questionText: "Me siento incómodo cuando un estudiante se desborda emocionalmente en clase (llanto o enojo), por lo que suelo pedirle que se tranquilice rápidamente para poder continuar con la lección.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Se valida el desborde y se le brinda la contención humana requerida"
  },
  {
    id: 102,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Fomento la participación activa y democrática de mis estudiantes en la elaboración de acuerdos y normas de convivencia en el aula, valorando sus aportes para construir un ambiente equitativo.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Construcción comunitaria de las pautas reguladoras del clima áulico"
  },
  {
    id: 103,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Cuando siento que el agotamiento mental sobrepasa mis propios recursos de afrontamiento, busco activamente apoyo en mis colegas o en los profesionales del Departamento de Consejería Estudiantil (DECE).",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Cuidado de la salud ocupacional e higiene mental docente indispensable"
  },
  {
    id: 104,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Frente a un conflicto, evito tomar partido basándome en prejuicios o en el historial de mala conducta de un alumno, garantizando que todos sean escuchados con imparcialidad y empatía.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Justicia procedimental, neutralidad e imparcialidad formativa áulica"
  },
  {
    id: 105,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Para no sobrecargar de preocupaciones a los representantes, prefiero reservar los incidentes de comportamiento o bajo rendimiento dentro del aula, informando a la familia solo cuando la situación es realmente crítica.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "La detección y alerta temprana al hogar es un derecho y deber compartido"
  },
  {
    id: 106,
    dimension: 3,
    category: "Autorregulación",
    questionText: "En situaciones de indisciplina reiterada reconozco que la presión del momento me dificulta mantener el tono de voz y la calma habitual.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "El control áulico saludable parte del autodominio emocional del maestro"
  },
  {
    id: 107,
    dimension: 3,
    category: "Autorregulación",
    questionText: "Diseño y aplico de manera sistemática estrategias de autocuidado personal para prevenir y gestionar saludablemente las tensiones acumuladas en mi jornada docente.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'B',
    justification: "Frecuentemente se aplican estas técnicas para mitigar el agotamiento laboral"
  },
  {
    id: 108,
    dimension: 3,
    category: "Empatía",
    questionText: "Me intereso genuinamente por la realidad comunitaria y familiar de mis alumnos, lo que me permite adaptar mis clases para no excluir a quienes carecen de recursos tecnológicos y económicos.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'A',
    justification: "Acomodación didáctica de equidad basada en el contexto sociofamiliar"
  },
  {
    id: 109,
    dimension: 3,
    category: "Empatía",
    questionText: "Siento que, con un currículo tan extenso, destinar tiempo a debates sobre justicia social o problemáticas globales me impide cubrir adecuadamente los temas de mi propia materia.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "Los contenidos transversales y de debate potencian y enriquecen la materia"
  },
  {
    id: 110,
    dimension: 3,
    category: "Relaciones Positivas",
    questionText: "Siento que las demandas socioemocionales de los estudiantes son una carga secundaria en comparación con los resultados de las pruebas estandarizadas académicas de fin de año.",
    options: [
      { letter: 'A', text: "Siempre, casi siempre" },
      { letter: 'B', text: "Frecuentemente" },
      { letter: 'C', text: "Rara vez" },
      { letter: 'D', text: "Nunca, casi nunca" }
    ],
    correctLetter: 'D',
    justification: "El desarrollo integral del alumno tiene igual o mayor relevancia que la nota sumativa"
  }
];
