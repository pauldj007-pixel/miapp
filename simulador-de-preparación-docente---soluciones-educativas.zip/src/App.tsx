import React, { useState, useEffect, useMemo } from 'react';
import { QUESTIONS } from './data';
import { Question, ExamAttempt, QuestionStats } from './types';
import Header from './components/Header';
import ExamInstructions from './components/ExamInstructions';
import StudyGuide from './components/StudyGuide';
import Simulator from './components/Simulator';
import StatsDashboard from './components/StatsDashboard';
import { BookOpen, ClipboardList, BarChart3, HelpCircle, Layers, GraduationCap } from 'lucide-react';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<'study' | 'simulator' | 'stats'>('simulator');

  // Core Persistent States (stored in localStorage)
  const [stats, setStats] = useState<{ [id: number]: QuestionStats }>({});
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);

  // Selected question ID for deep linking
  const [deepLinkQuestionId, setDeepLinkQuestionId] = useState<number | null>(null);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const storedStats = localStorage.getItem('soluciones_docente_stats');
      if (storedStats) {
        setStats(JSON.parse(storedStats));
      } else {
        // Initialize default empty stats for all 163 questions
        const initialStats: { [id: number]: QuestionStats } = {};
        QUESTIONS.forEach(q => {
          initialStats[q.id] = {
            questionId: q.id,
            timesAnswered: 0,
            correctAnswers: 0,
            isFavorite: false,
            userNote: ''
          };
        });
        setStats(initialStats);
      }

      const storedAttempts = localStorage.getItem('soluciones_docente_attempts');
      if (storedAttempts) {
        setAttempts(JSON.parse(storedAttempts));
      }
    } catch (e) {
      console.error('Error loading data from localStorage', e);
    }
  }, []);

  // Sync to localStorage on stats change
  const saveStats = (newStats: { [id: number]: QuestionStats }) => {
    setStats(newStats);
    localStorage.setItem('soluciones_docente_stats', JSON.stringify(newStats));
  };

  // Sync to localStorage on attempts change
  const saveAttempts = (newAttempts: ExamAttempt[]) => {
    setAttempts(newAttempts);
    localStorage.setItem('soluciones_docente_attempts', JSON.stringify(newAttempts));
  };

  // Global Progress Metrics Calculation
  const totalPracticed = useMemo(() => {
    const values = Object.values(stats) as QuestionStats[];
    return values.filter(s => s.timesAnswered > 0 || (s.userNote && s.userNote.trim() !== '')).length;
  }, [stats]);

  const globalAccuracy = useMemo(() => {
    // Calculate accuracy based on all exam attempts
    if (attempts.length === 0) return 0;
    const totalCorrect = attempts.reduce((acc, curr) => acc + curr.correctCount, 0);
    const totalQuestions = attempts.reduce((acc, curr) => acc + curr.totalCount, 0);
    return totalQuestions > 0 ? Math.round((totalCorrect / totalQuestions) * 100) : 0;
  }, [attempts]);

  // Handler: Toggle Favorite / Bookmark
  const handleToggleFavorite = (id: number) => {
    const currentQStats = stats[id] || {
      questionId: id,
      timesAnswered: 0,
      correctAnswers: 0,
      isFavorite: false,
      userNote: ''
    };

    const updatedStats = {
      ...stats,
      [id]: {
        ...currentQStats,
        isFavorite: !currentQStats.isFavorite
      }
    };
    saveStats(updatedStats);
  };

  // Handler: Save custom Study Notes
  const handleSaveNote = (id: number, note: string) => {
    const currentQStats = stats[id] || {
      questionId: id,
      timesAnswered: 0,
      correctAnswers: 0,
      isFavorite: false,
      userNote: ''
    };

    const updatedStats = {
      ...stats,
      [id]: {
        ...currentQStats,
        userNote: note
      }
    };
    saveStats(updatedStats);
  };

  // Handler: Clear Attempts History
  const handleClearAttempts = () => {
    saveAttempts([]);
  };

  // Handler: Reset All Progress & Stats
  const handleResetAllProgress = () => {
    const initialStats: { [id: number]: QuestionStats } = {};
    QUESTIONS.forEach(q => {
      initialStats[q.id] = {
        questionId: q.id,
        timesAnswered: 0,
        correctAnswers: 0,
        isFavorite: false,
        userNote: ''
      };
    });
    saveStats(initialStats);
    saveAttempts([]);
  };

  // Handler: Record new attempt from Simulator
  const handleRecordAttempt = (newAttempt: ExamAttempt) => {
    const updatedAttempts = [...attempts, newAttempt];
    saveAttempts(updatedAttempts);

    // Update stats per question
    const updatedStats = { ...stats };
    Object.entries(newAttempt.answers).forEach(([qIdStr, ansLetter]) => {
      const qId = parseInt(qIdStr);
      const actualQ = QUESTIONS.find(question => question.id === qId);
      if (actualQ) {
        if (!updatedStats[qId]) {
          updatedStats[qId] = {
            questionId: qId,
            timesAnswered: 0,
            correctAnswers: 0,
            isFavorite: false,
            userNote: ''
          };
        }
        updatedStats[qId].timesAnswered++;
        if (ansLetter === actualQ.correctLetter) {
          updatedStats[qId].correctAnswers++;
        }
      }
    });
    saveStats(updatedStats);
  };

  // Deep Link: Navigate from Stats list to specific question card
  const handleNavigateToQuestion = (id: number) => {
    setDeepLinkQuestionId(id);
    setActiveTab('study');
    
    // Auto scroll down to the study guide section smoothly
    setTimeout(() => {
      const el = document.getElementById('study-guide-workspace');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }, 150);
  };

  return (
    <div className="min-h-screen bg-[#F1F5F9] text-slate-900 antialiased py-6 px-4 md:px-8 space-y-6 max-w-7xl mx-auto" id="app-workspace">
      {/* Brand Launcher indicator & welcome header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-200/80">
        <div className="flex items-center gap-2">
          <GraduationCap className="w-6 h-6 text-indigo-600" />
          <span className="font-display font-bold text-slate-800 text-sm tracking-wide">
            PORTAL DOCENTE
          </span>
        </div>
        <div className="text-[11px] font-mono text-slate-400 font-medium">
          Evaluación Nacional EVDO 2026 ECUADOR
        </div>
      </div>

      {/* Main Stats Header */}
      <Header
        totalPracticed={totalPracticed}
        totalCorrect={0} // Computed inside precision
        overallAccuracy={globalAccuracy}
        onResetStats={handleResetAllProgress}
      />

      {/* General strategies and instructions guide (Ineval tips) */}
      <ExamInstructions />

      {/* Mode navigation / Toggle controls */}
      <div className="flex bg-slate-200/50 backdrop-blur-sm p-1.5 rounded-2xl border border-slate-200 max-w-lg mx-auto md:max-w-md shadow-sm" id="tab-nav">
        <button
          onClick={() => {
            setActiveTab('study');
            setDeepLinkQuestionId(null);
          }}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs md:text-sm font-semibold transition-all duration-200 ${
            activeTab === 'study'
              ? 'bg-indigo-600 text-white shadow-md font-bold scale-[1.02]'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/40'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Guía de Estudio</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('simulator');
            setDeepLinkQuestionId(null);
          }}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs md:text-sm font-semibold transition-all duration-200 ${
            activeTab === 'simulator'
              ? 'bg-indigo-600 text-white shadow-md font-bold scale-[1.02]'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/40'
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          <span>Simulador</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('stats');
            setDeepLinkQuestionId(null);
          }}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs md:text-sm font-semibold transition-all duration-200 ${
            activeTab === 'stats'
              ? 'bg-indigo-600 text-white shadow-md font-bold scale-[1.02]'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/40'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Mi Progreso</span>
        </button>
      </div>

      {/* Core Dynamic Content Areas */}
      <main className="transition-all duration-300">
        {activeTab === 'study' && (
          <StudyGuide
            questions={QUESTIONS}
            stats={stats}
            onToggleFavorite={handleToggleFavorite}
            onSaveNote={handleSaveNote}
          />
        )}

        {activeTab === 'simulator' && (
          <Simulator
            questions={QUESTIONS}
            stats={stats}
            onToggleFavorite={handleToggleFavorite}
            onRecordAttempt={handleRecordAttempt}
          />
        )}

        {activeTab === 'stats' && (
          <StatsDashboard
            questions={QUESTIONS}
            stats={stats}
            attempts={attempts}
            onClearAttempts={handleClearAttempts}
            onNavigateToQuestion={handleNavigateToQuestion}
          />
        )}
      </main>

      {/* Footer copyright */}
      <footer className="pt-8 border-t border-slate-200 text-center text-xs text-slate-400 font-sans" id="app-footer">
        <div>
          © 2026 Soluciones Educativas. Material de preparación de uso libre para docentes. <span className="text-slate-300 mx-1.5">•</span> <strong>Design by: PaulDjLeSeul</strong>
        </div>
        <div className="mt-1 text-[10px] text-slate-400">
          Diseñado bajo las directrices y estándares oficiales de la Rúbrica de Desempeño Profesional.
        </div>
      </footer>
    </div>
  );
}
